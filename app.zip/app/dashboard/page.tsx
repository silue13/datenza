"use client";

import { useData } from "../context/DataContext";
import { Bar, Line, Pie, Doughnut, Radar } from "react-chartjs-2";
import CarteGeographique from "../components/CarteGeographique";
import "../components/chartSetup";

export default function DashboardPage() {
  const { nomFichier, corps, entetes, resultat, graphiquesEpingles, desepinglerGraphique } = useData();
  const manquants = resultat
    ? Object.values(resultat.statistiques).reduce((s, c) => s + c.nbVides, 0)
    : null;
  const totalCellules = corps.length * entetes.length;
  const tauxCompletude = manquants === null || totalCellules === 0
    ? null
    : Math.max(0, Math.min(100, Math.round(((totalCellules - manquants) / totalCellules) * 100)));

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    resizeDelay: 120,
    animation: { duration: 650, easing: "easeOutQuart" as const },
    interaction: { mode: "index" as const, intersect: false },
    layout: { padding: { top: 8, right: 12, bottom: 4, left: 8 } },
    plugins: {
      legend: {
        display: true,
        position: "bottom" as const,
        labels: {
          usePointStyle: true,
          pointStyle: "circle" as const,
          boxWidth: 8,
          boxHeight: 8,
          padding: 18,
          color: "#64748b",
          font: { family: "Inter, ui-sans-serif, system-ui", size: 11, weight: 600 as const },
        },
      },
      tooltip: {
        backgroundColor: "#0f172a",
        titleColor: "#f8fafc",
        bodyColor: "#e2e8f0",
        borderColor: "#334155",
        borderWidth: 1,
        padding: 12,
        cornerRadius: 10,
        displayColors: true,
        usePointStyle: true,
      },
    },
    scales: {
      x: {
        border: { display: false },
        grid: { display: false },
        ticks: { color: "#64748b", maxRotation: 35, minRotation: 0, font: { family: "Inter, ui-sans-serif, system-ui", size: 10, weight: 500 as const } },
      },
      y: {
        beginAtZero: true,
        border: { display: false, dash: [4, 4] },
        grid: { color: "rgba(148,163,184,0.18)", tickLength: 0 },
        ticks: { color: "#64748b", padding: 10, font: { family: "Inter, ui-sans-serif, system-ui", size: 10, weight: 500 as const } },
      },
    },
    elements: {
      bar: { borderRadius: 7, borderSkipped: false },
      line: { borderWidth: 3, tension: 0.32, capBezierPoints: true },
      point: { radius: 3, hoverRadius: 6, hitRadius: 10, borderWidth: 2, backgroundColor: "#ffffff" },
      arc: { borderWidth: 3, borderColor: "#ffffff", hoverOffset: 7 },
    },
  } as const;

  function imprimerRapport() {
    window.print();
  }

  if (!corps || corps.length === 0) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-5xl items-center justify-center py-12 print:hidden">
        <div className="w-full max-w-xl rounded-3xl border border-slate-200 bg-white p-10 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-50 text-3xl dark:bg-cyan-950/50">▤</div>
          <p className="text-xs font-bold uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">DATENZA · PILOTAGE</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Votre tableau de bord</h1>
          <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-slate-500 dark:text-slate-400">
            Chargez un fichier depuis l’accueil pour retrouver ici les indicateurs clés, la qualité des données et vos visualisations.
          </p>
          <div className="mt-7 inline-flex items-center gap-2 rounded-xl border border-dashed border-slate-300 px-4 py-3 text-xs font-semibold text-slate-500 dark:border-slate-700 dark:text-slate-400">
            <span className="text-base">↗</span> En attente d’un jeu de données
          </div>
        </div>
      </div>
    );
  }

  const indicateurs = [
    { label: "Lignes analysées", valeur: corps.length.toLocaleString("fr-FR"), detail: "Enregistrements du fichier", symbole: "▤", couleur: "cyan" },
    { label: "Colonnes disponibles", valeur: entetes.length.toLocaleString("fr-FR"), detail: "Variables exploitables", symbole: "▦", couleur: "blue" },
    { label: "Visualisations", valeur: graphiquesEpingles.length.toLocaleString("fr-FR"), detail: "Graphiques épinglés", symbole: "◫", couleur: "violet" },
    { label: "Valeurs manquantes", valeur: manquants === null ? "—" : manquants.toLocaleString("fr-FR"), detail: tauxCompletude === null ? "Lancez une analyse pour vérifier" : `${tauxCompletude}% de complétude estimée`, symbole: "◌", couleur: manquants ? "amber" : "emerald" },
  ];

  const palette: Record<string, string> = {
    cyan: "bg-cyan-50 text-cyan-700 ring-cyan-100 dark:bg-cyan-950/50 dark:text-cyan-300 dark:ring-cyan-900",
    blue: "bg-blue-50 text-blue-700 ring-blue-100 dark:bg-blue-950/50 dark:text-blue-300 dark:ring-blue-900",
    violet: "bg-violet-50 text-violet-700 ring-violet-100 dark:bg-violet-950/50 dark:text-violet-300 dark:ring-violet-900",
    amber: "bg-amber-50 text-amber-700 ring-amber-100 dark:bg-amber-950/50 dark:text-amber-300 dark:ring-amber-900",
    emerald: "bg-emerald-50 text-emerald-700 ring-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-900",
  };

  return (
    <div className="mx-auto max-w-[1600px] space-y-7 pb-12 font-sans print:max-w-full print:p-0">
      <header className="relative isolate overflow-hidden rounded-[28px] bg-gradient-to-br from-slate-950 via-cyan-950 to-slate-900 px-6 py-7 text-white shadow-xl shadow-cyan-950/10 sm:px-9 sm:py-9 print:bg-slate-900">
        <div className="pointer-events-none absolute -right-12 -top-28 -z-10 h-80 w-80 rounded-full border border-white/10" />
        <div className="pointer-events-none absolute -right-2 -top-16 -z-10 h-60 w-60 rounded-full border border-white/10" />
        <div className="pointer-events-none absolute bottom-[-90px] right-[22%] -z-10 h-52 w-52 rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="min-w-0">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-200/20 bg-white/5 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-cyan-200">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]" /> DATENZA · CENTRE DE PILOTAGE
            </div>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Tableau de bord</h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-300">Une vue synthétique de votre jeu de données, de sa qualité et des analyses que vous avez sélectionnées.</p>
            <div className="mt-5 flex max-w-full items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 sm:max-w-xl">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-400/15 text-xl text-cyan-200">▤</div>
              <div className="min-w-0">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Fichier actif</p>
                <p className="truncate text-sm font-semibold text-white" title={nomFichier}>{nomFichier || "Jeu de données importé"}</p>
              </div>
              <span className="ml-auto shrink-0 rounded-lg border border-emerald-300/20 bg-emerald-300/10 px-2.5 py-1 text-[10px] font-semibold text-emerald-200">Chargé</span>
            </div>
          </div>
          <button onClick={imprimerRapport} className="print:hidden inline-flex shrink-0 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white px-4 py-3 text-sm font-bold text-slate-900 shadow-lg transition hover:-translate-y-0.5 hover:bg-cyan-50 focus:outline-none focus:ring-4 focus:ring-cyan-300/30">
            <span className="text-lg">⇩</span> Exporter le rapport PDF
          </button>
        </div>
      </header>

      <section aria-label="Indicateurs clés" className="grid grid-cols-1 gap-4 sm:grid-cols-2 2xl:grid-cols-4">
        {indicateurs.map((item, index) => (
          <article key={item.label} className="group relative overflow-hidden rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm transition duration-200 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-slate-200/60 dark:border-slate-800 dark:bg-slate-900 dark:hover:shadow-black/20">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">{item.label}</p>
                <p className="mt-3 text-3xl font-bold tracking-tight text-slate-950 dark:text-white">{item.valeur}</p>
              </div>
              <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-xl ring-1 ${palette[item.couleur]}`}>{item.symbole}</div>
            </div>
            <p className="mt-4 flex items-center gap-2 text-[11px] leading-5 text-slate-500 dark:text-slate-400"><span className="h-1.5 w-1.5 rounded-full bg-slate-300 dark:bg-slate-600" />{item.detail}</p>
            <div className={`absolute bottom-0 left-0 h-[3px] w-full ${index === 0 ? "bg-cyan-500" : index === 1 ? "bg-blue-500" : index === 2 ? "bg-violet-500" : manquants ? "bg-amber-500" : "bg-emerald-500"}`} />
          </article>
        ))}
      </section>

      <section className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1.5fr)_minmax(280px,0.7fr)]">
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">Structure du fichier</p>
              <h2 className="mt-1 text-lg font-bold text-slate-900 dark:text-white">Profil des données</h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Vue d’ensemble du volume et des champs disponibles.</p>
            </div>
            <span className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:bg-slate-800 dark:text-slate-300">Résumé</span>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-slate-50 p-4 dark:bg-slate-800/60"><p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Enregistrements</p><p className="mt-2 text-xl font-bold text-slate-900 dark:text-white">{corps.length.toLocaleString("fr-FR")}</p></div>
            <div className="rounded-xl bg-slate-50 p-4 dark:bg-slate-800/60"><p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Variables</p><p className="mt-2 text-xl font-bold text-slate-900 dark:text-white">{entetes.length.toLocaleString("fr-FR")}</p></div>
            <div className="col-span-2 rounded-xl bg-slate-50 p-4 dark:bg-slate-800/60 sm:col-span-1"><p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Cellules estimées</p><p className="mt-2 text-xl font-bold text-slate-900 dark:text-white">{totalCellules.toLocaleString("fr-FR")}</p></div>
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:p-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">Qualité des données</p>
          <h2 className="mt-1 text-lg font-bold text-slate-900 dark:text-white">Complétude</h2>
          {tauxCompletude === null ? (
            <div className="mt-5 rounded-xl border border-dashed border-slate-200 p-4 text-xs leading-5 text-slate-500 dark:border-slate-700 dark:text-slate-400">Lancez l’analyse des données pour afficher une estimation de la complétude.</div>
          ) : (
            <>
              <div className="mt-5 flex items-end justify-between gap-3"><p className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">{tauxCompletude}<span className="ml-1 text-base font-semibold text-slate-400">%</span></p><p className="pb-1 text-[11px] text-slate-500">{manquants!.toLocaleString("fr-FR")} cellule(s) manquante(s)</p></div>
              <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800"><div className={`h-full rounded-full transition-all ${tauxCompletude >= 90 ? "bg-emerald-500" : tauxCompletude >= 70 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${tauxCompletude}%` }} /></div>
              <p className="mt-3 text-[11px] leading-5 text-slate-500 dark:text-slate-400">Indicateur descriptif basé sur les cellules déclarées manquantes par l’analyse.</p>
            </>
          )}
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">Vos analyses</p>
            <h2 className="mt-1 text-xl font-bold tracking-tight text-slate-900 dark:text-white">Visualisations sélectionnées</h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Les graphiques épinglés depuis la page Analyse sont regroupés ici.</p>
          </div>
          <span className="inline-flex w-fit items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"><span className="h-1.5 w-1.5 rounded-full bg-cyan-500" />{graphiquesEpingles.length} visualisation(s)</span>
        </div>

        {graphiquesEpingles.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center dark:border-slate-700 dark:bg-slate-900/70">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-50 text-2xl text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300">◫</div>
            <h3 className="mt-4 text-sm font-bold text-slate-800 dark:text-white">Votre espace de visualisation est prêt</h3>
            <p className="mx-auto mt-2 max-w-md text-xs leading-5 text-slate-500 dark:text-slate-400">Aucun graphique épinglé pour le moment. Ouvrez la page Analyse, créez une visualisation puis choisissez « Ajouter au tableau de bord ».</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 2xl:grid-cols-2">
            {graphiquesEpingles.map((g, index) => (
              <article key={g.id} className={`${g.type === "Carte" ? "2xl:col-span-2" : ""} group min-w-0 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm transition duration-200 hover:shadow-lg hover:shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:hover:shadow-black/20 print:break-inside-avoid`}>
                <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4 dark:border-slate-800 sm:px-6">
                  <div className="flex min-w-0 items-start gap-3">
                    <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold ${index % 3 === 0 ? "bg-cyan-50 text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300" : index % 3 === 1 ? "bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300" : "bg-violet-50 text-violet-700 dark:bg-violet-950/50 dark:text-violet-300"}`}>{String(index + 1).padStart(2, "0")}</div>
                    <div className="min-w-0 pt-0.5"><h3 className="truncate text-sm font-bold text-slate-900 dark:text-white" title={g.titre}>{g.titre}</h3><p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400">{g.type === "Aires" ? "Courbe avec aire" : g.type === "Carte" ? "Carte géographique" : `Graphique · ${g.type}`}</p></div>
                  </div>
                  <button onClick={() => desepinglerGraphique(g.id)} aria-label={`Retirer ${g.titre} du tableau de bord`} className="print:hidden shrink-0 rounded-lg border border-slate-200 px-3 py-2 text-[10px] font-semibold text-slate-500 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 dark:border-slate-700 dark:text-slate-400 dark:hover:border-rose-900 dark:hover:bg-rose-950/40 dark:hover:text-rose-300">Retirer <span aria-hidden="true">×</span></button>
                </div>
                <div className={`${g.type === "Carte" ? "min-h-[420px]" : "h-[330px] sm:h-[360px]"} min-w-0 p-4 sm:p-5`}>
                  {g.type === "Carte" && <div className="h-full min-h-[390px] w-full"><CarteGeographique entetes={entetes} corps={corps} /></div>}
                  {g.type === "Barres" && <Bar data={g} options={options} />}
                  {(g.type === "Courbe" || g.type === "Aires") && <Line data={g} options={{ ...options, elements: { ...options.elements, line: { ...options.elements.line, fill: g.type === "Aires" } } }} />}
                  {g.type === "Camembert" && <Pie data={g} options={options} />}
                  {g.type === "Anneau" && <Doughnut data={g} options={{ ...options, cutout: "68%" }} />}
                  {g.type === "Radar" && <Radar data={g} options={{ ...options, scales: { r: { angleLines: { color: "rgba(148,163,184,0.22)" }, grid: { color: "rgba(148,163,184,0.22)" }, pointLabels: { color: "#64748b", font: { size: 10, weight: 500 as const } }, ticks: { backdropColor: "transparent", color: "#94a3b8", showLabelBackdrop: false } } } }} />}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
      <footer className="flex flex-col gap-2 border-t border-slate-200 pt-5 text-[10px] text-slate-400 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between print:hidden"><span>DATENZA · Tableau de bord analytique</span><span>Les indicateurs affichés reflètent le jeu de données actif.</span></footer>
    </div>
  );
}
