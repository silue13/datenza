"use client";
import { useMemo } from "react";
import dynamic from "next/dynamic";
import "leaflet/dist/leaflet.css";
import { centre, contourValide, formaterCoord, type Coord, type ParcelleCadastre } from "../../lib/monchamp/cadastre";
import { creerFormateurs } from "../../lib/analyse/format";

const MapContainer = dynamic(() => import("react-leaflet").then((m) => m.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import("react-leaflet").then((m) => m.TileLayer), { ssr: false });
const Polygon = dynamic(() => import("react-leaflet").then((m) => m.Polygon), { ssr: false });
const Polyline = dynamic(() => import("react-leaflet").then((m) => m.Polyline), { ssr: false });
const CircleMarker = dynamic(() => import("react-leaflet").then((m) => m.CircleMarker), { ssr: false });
const Popup = dynamic(() => import("react-leaflet").then((m) => m.Popup), { ssr: false });
const OutilsCarteParcelles = dynamic(() => import("./OutilsCarteParcelles"), { ssr: false });

const f = creerFormateurs("fr");

export type Fond = "satellite" | "plan";

const FONDS: Record<Fond, { url: string; attribution: string; maxNativeZoom: number }> = {
  satellite: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Imagerie &copy; Esri, Maxar, Earthstar Geographics et la communauté des utilisateurs SIG",
    maxNativeZoom: 18,
  },
  plan: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxNativeZoom: 19,
  },
};

interface Props {
  parcelles: ParcelleCadastre[];
  selectionId: number | null;
  trace: Coord[] | null; // contour en cours de tracé ; null = aucun tracé
  fond: Fond;
  cleVue: string;
  onClic: (c: Coord) => void;
  onSelection: (id: number) => void;
}

export default function CarteParcelles({ parcelles, selectionId, trace, fond, cleVue, onClic, onSelection }: Props) {
  const tracees = useMemo(
    () => parcelles.filter((p): p is ParcelleCadastre & { contour: Coord[] } => contourValide(p.contour)),
    [parcelles]
  );
  const cibles = useMemo(() => {
    const selection = tracees.find((p) => p.id === selectionId);
    if (trace && trace.length) return trace;
    if (selection) return selection.contour;
    return tracees.flatMap((p) => p.contour);
  }, [tracees, selectionId, trace]);

  const cfg = FONDS[fond];

  return (
    <div className="h-[480px] w-full rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 relative">
      <MapContainer center={[7.54, -5.55]} zoom={6} maxZoom={19} scrollWheelZoom className="h-full w-full">
        <TileLayer key={fond} attribution={cfg.attribution} url={cfg.url} maxNativeZoom={cfg.maxNativeZoom} maxZoom={19} />
        <OutilsCarteParcelles cibles={cibles} cleVue={cleVue} tracage={trace !== null} onClic={onClic} />

        {tracees.map((p) => {
          const actif = p.id === selectionId;
          const c = centre(p.contour);
          return (
            <Polygon
              key={p.id}
              positions={p.contour}
              pathOptions={{ color: actif ? "#facc15" : "#c084fc", weight: actif ? 3 : 2, fillColor: actif ? "#facc15" : "#a855f7", fillOpacity: 0.22 }}
              eventHandlers={{ click: () => { if (trace === null) onSelection(p.id); } }}
            >
              <Popup>
                <div className="text-xs font-semibold p-1">
                  <p className="text-purple-700 font-bold">{p.nom}</p>
                  <p>{f.nombre(p.superficieHa)} ha{p.localite ? ` · ${p.localite}` : ""}</p>
                  {c && <p className="text-slate-500 font-normal">{formaterCoord(c)}</p>}
                </div>
              </Popup>
            </Polygon>
          );
        })}

        {trace && trace.length >= 3 && (
          <Polygon positions={trace} pathOptions={{ color: "#22d3ee", weight: 2, dashArray: "6 6", fillColor: "#22d3ee", fillOpacity: 0.15 }} />
        )}
        {trace && trace.length === 2 && <Polyline positions={trace} pathOptions={{ color: "#22d3ee", weight: 2, dashArray: "6 6" }} />}
        {trace &&
          trace.map((pt, i) => (
            <CircleMarker key={`${i}-${pt[0]}-${pt[1]}`} center={pt} radius={5} pathOptions={{ color: "#0891b2", fillColor: "#ffffff", fillOpacity: 1, weight: 2 }} />
          ))}
      </MapContainer>
    </div>
  );
}