"use client";
import { useMemo, useRef, useState } from "react";
import { Bar, Line, Pie, Doughnut, Radar } from "react-chartjs-2";
import CarteGeographique from "./CarteGeographique";
import "./chartSetup";
import { arrondir, estValeurVide, type Cellule } from "../../lib/analyse/utils";
import type { GraphiqueEpingle, TypeGraphique } from "../context/DataContext";

type Agregation = "Nombre" | "Somme" | "Moyenne" | "Mediane" | "Minimum" | "Maximum" | "Valeurs distinctes" | "Pourcentage";

interface GraphiqueGenerateurProps {
  entetes: string[];
  corps: Cellule[][];
  onEpingler?: (graphique: GraphiqueEpingle) => void;
}

const PALETTE = ["#9333ea", "#a855f7", "#c084fc", "#3b82f6", "#60a5fa", "#10b981", "#f59e0b", "#e11d48", "#64748b", "#14b8a6"];
const MAX_CATEGORIES = 20;
const MAX_PARTS_CAMEMBERT = 8;

function versNombre(v: Cellule): number | null {
  if (estValeurVide(v)) return null;
  const n = Number(typeof v === "string" ? v.trim().replace(",", ".") : v);
  return Number.isFinite(n) ? n : null;
}

const selectClasse =
  "w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-xs font-medium focus:ring-2 focus:ring-purple-500";

export default function GraphiqueGenerateur({ entetes, corps, onEpingler }: GraphiqueGenerateurProps) {
  const [typeGraphique, setTypeGraphique] = useState<TypeGraphique>("Barres");
  const [colonneAxeX, setColonneAxeX] = useState<string>(entetes[0] || "");
  const [colonneAxeY, setColonneAxeY] = useState<string>(entetes[1] || entetes[0] || "");
  const [agregation, setAgregation] = useState<Agregation>("Nombre");
  const [graphiquesGeneres, setGraphiquesGeneres] = useState<GraphiqueEpingle[]>([]);
  const [message, setMessage] = useState<string>("");
  const [suggestionActive, setSuggestionActive] = useState<number | null>(null);
  const compteur = useRef(0);

  // Recommandations automatiques génériques : les choix dépendent du profil réel
  // des colonnes, jamais d'un secteur métier ou d'un nom de fichier particulier.
  const graphiquesRecommandes = useMemo<GraphiqueEpingle[]>(() => {
    if (!entetes.length || !corps.length) return [];

    const normaliser = (v: Cellule) => String(v ?? "").trim();
    const normaliserNom = (v: string) => v.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const ressembleDate = (v: Cellule): number | null => {
      const texte = normaliser(v);
      if (!texte) return null;
      // Évite de prendre les nombres seuls (ex. 2024) pour des dates.
      if (!/[\/-]|T|\s/.test(texte)) return null;
      const temps = Date.parse(texte);
      return Number.isNaN(temps) ? null : temps;
    };
    const colonnes = entetes.map((nom, index) => {
      const valeurs = corps.map((ligne) => ligne[index]).filter((v) => !estValeurVide(v));
      const nombres = valeurs.map(versNombre).filter((v): v is number => v !== null);
      const uniques = new Set(valeurs.map(normaliser));
      const nomN = normaliserNom(nom);
      const tauxNumerique = valeurs.length ? nombres.length / valeurs.length : 0;
      const tauxDate = valeurs.length ? valeurs.filter((v) => ressembleDate(v) !== null).length / valeurs.length : 0;
      const nomIdentifiant = /(^|[^a-z])(id|identifiant|uuid|guid|matricule|code|reference|ref|numero|num|n°)([^a-z]|$)/.test(nomN);
      const tauxUnique = valeurs.length ? uniques.size / valeurs.length : 0;
      // Une colonne presque unique est généralement une clé/identifiant, pas une catégorie utile.
      const identifiant = nomIdentifiant || (valeurs.length >= 12 && tauxUnique >= 0.9 && tauxNumerique < 0.9);
      const numerique = tauxNumerique >= 0.8 && nombres.length >= 3 && !identifiant;
      const date = tauxDate >= 0.7 && !numerique;
      const categorielle = !numerique && !date && !identifiant && uniques.size >= 2 && uniques.size <= 15;
      return { nom, index, valeurs, nombres, uniques, tauxUnique, identifiant, numerique, date, categorielle };
    });

    const numeriques = colonnes.filter((c) => c.numerique);
    const dates = colonnes.filter((c) => c.date);
    const categories = colonnes.filter((c) => c.categorielle);
    const resultats: GraphiqueEpingle[] = [];
    const couleurs = ["#0e7490", "#0891b2", "#14b8a6", "#6366f1", "#f59e0b", "#8b5cf6"];
    const maxSuggestions = 4;
    const creerBarres = (titre: string, label: string, labels: string[], valeurs: number[], couleur: string, id: number): GraphiqueEpingle => ({
      id,
      titre,
      type: "Barres",
      labels,
      datasets: [{ label, data: valeurs, backgroundColor: couleur, borderColor: couleur, borderWidth: 1 }],
    });

    // 1. Temps + mesure numérique : tendance temporelle, regroupée par mois.
    if (dates.length && numeriques.length) {
      const dateCol = dates[0];
      const mesure = numeriques.find((c) => c.index !== dateCol.index);
      if (mesure) {
        const groupes = new Map<string, { somme: number; n: number }>();
        for (const ligne of corps) {
          const temps = ressembleDate(ligne[dateCol.index]);
          const valeur = versNombre(ligne[mesure.index]);
          if (temps === null || valeur === null) continue;
          const d = new Date(temps);
          const cle = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
          const g = groupes.get(cle) ?? { somme: 0, n: 0 };
          g.somme += valeur; g.n += 1;
          groupes.set(cle, g);
        }
        const points = [...groupes.entries()].sort((a, b) => a[0].localeCompare(b[0]));
        if (points.length >= 3) {
          resultats.push({
            id: 920001,
            titre: `Évolution mensuelle de ${mesure.nom}`,
            type: "Courbe",
            labels: points.map(([mois]) => mois),
            datasets: [{ label: `Moyenne de ${mesure.nom}`, data: points.map(([, g]) => arrondir(g.somme / g.n)), borderColor: "#0e7490", backgroundColor: "rgba(14,116,144,0.15)", borderWidth: 2 }],
          });
        }
      }
    }

    // 2. Catégorie + mesure : comparaison de moyennes, seulement si plusieurs groupes
    // ont suffisamment de valeurs numériques pour rendre la comparaison exploitable.
    for (const cat of categories) {
      const mesure = numeriques.find((c) => c.index !== cat.index);
      if (!mesure || resultats.length >= maxSuggestions) continue;
      const groupes = new Map<string, { somme: number; n: number }>();
      for (const ligne of corps) {
        const categorie = ligne[cat.index];
        const nombre = versNombre(ligne[mesure.index]);
        if (estValeurVide(categorie) || nombre === null) continue;
        const cle = normaliser(categorie);
        const g = groupes.get(cle) ?? { somme: 0, n: 0 };
        g.somme += nombre; g.n += 1; groupes.set(cle, g);
      }
      const points = [...groupes.entries()].filter(([, g]) => g.n > 0)
        .map(([label, g]) => ({ label, valeur: g.somme / g.n, n: g.n }))
        .sort((a, b) => b.valeur - a.valeur).slice(0, 10);
      if (points.length >= 2) {
        resultats.push(creerBarres(`Moyenne de ${mesure.nom} par ${cat.nom}`, `Moyenne — ${mesure.nom}`, points.map((p) => p.label), points.map((p) => arrondir(p.valeur)), couleurs[resultats.length % couleurs.length], 920010 + resultats.length));
      }
    }

    // 3. Répartition des enregistrements : seulement pour une catégorie de faible cardinalité.
    // On évite les colonnes d'identifiants et les catégories avec trop de modalités.
    if (resultats.length < maxSuggestions) {
      const cat = categories.find((c) => c.uniques.size >= 2 && c.uniques.size <= 10);
      if (cat) {
        const compte = new Map<string, number>();
        for (const ligne of corps) {
          if (estValeurVide(ligne[cat.index])) continue;
          const cle = normaliser(ligne[cat.index]);
          compte.set(cle, (compte.get(cle) ?? 0) + 1);
        }
        const points = [...compte.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10);
        if (points.length >= 2) {
          resultats.push(creerBarres(`Répartition des enregistrements par ${cat.nom}`, "Nombre d’enregistrements", points.map(([label]) => label), points.map(([, n]) => n), couleurs[resultats.length % couleurs.length], 920020 + resultats.length));
        }
      }
    }

    // 4. Si aucune combinaison de catégorie/temps n'est valable, montrer une distribution
    // par classes d'une mesure continue. Ne jamais compter les valeurs numériques brutes.
    if (resultats.length === 0) {
      const col = numeriques.find((c) => c.nombres.length >= 6 && c.uniques.size >= 6);
      if (col) {
        const vals = corps.map((ligne) => versNombre(ligne[col.index])).filter((n): n is number => n !== null);
        const min = Math.min(...vals), max = Math.max(...vals);
        if (max > min) {
          const nbClasses = Math.min(8, Math.max(4, Math.ceil(Math.sqrt(vals.length))));
          const largeur = (max - min) / nbClasses;
          const comptes = Array.from({ length: nbClasses }, () => 0);
          for (const n of vals) comptes[Math.min(nbClasses - 1, Math.floor((n - min) / largeur))]++;
          resultats.push(creerBarres(`Distribution de ${col.nom}`, "Nombre d’observations", comptes.map((_, i) => `${arrondir(min + i * largeur)} – ${arrondir(i === nbClasses - 1 ? max : min + (i + 1) * largeur)}`), comptes, "#0e7490", 920030));
        }
      }
    }

    // Classement heuristique transparent : une tendance temporelle est prioritaire,
    // puis une comparaison de mesure par catégorie, une répartition et enfin une distribution.
    // Le classement ne change ni les données calculées ni les graphiques eux-mêmes.
    const scoreInteret = (g: GraphiqueEpingle) => {
      if (g.type === "Courbe" && /évolution|evolution|mensuelle|temporelle/i.test(g.titre)) return 95;
      if (/moyenne de .* par /i.test(g.titre)) return 85;
      if (/répartition des enregistrements/i.test(g.titre)) return 75;
      if (/^distribution de /i.test(g.titre)) return 65;
      return 50;
    };
    return resultats
      .filter((g, i, arr) => g.labels.length >= 2 && g.datasets[0].data.some((v) => Number.isFinite(Number(v))) && arr.findIndex((autre) => autre.titre === g.titre) === i)
      .sort((a, b) => scoreInteret(b) - scoreInteret(a))
      .slice(0, maxSuggestions);
  }, [entetes, corps]);

  function personnaliserSuggestion(g: GraphiqueEpingle) {
    const normaliser = (v: string) => v.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const titreN = normaliser(g.titre);
    const colonneDansTitre = entetes.find((nom) => titreN.includes(normaliser(nom)));
    const mesureLabel = String(g.datasets[0]?.label ?? "").replace(/^(moyenne|nombre d’enregistrements|nombre d'observations|moyenne de)\s*[—-]?\s*/i, "").trim();
    const mesure = entetes.find((nom) => normaliser(nom) === normaliser(mesureLabel))
      ?? entetes.find((nom) => titreN.includes(normaliser(nom)) && nom !== colonneDansTitre);
    const categorie = entetes.find((nom) => titreN.includes(` par ${normaliser(nom)}`))
      ?? entetes.find((nom) => titreN.includes(` selon ${normaliser(nom)}`));
    if (categorie) setColonneAxeX(categorie);
    else if (/évolution|evolution|mensuelle/i.test(titreN)) {
      const colDate = entetes.find((nom) => corps.some((ligne) => {
        const v = String(ligne[entetes.indexOf(nom)] ?? "").trim();
        return /[\/-]|T|\s/.test(v) && !Number.isNaN(Date.parse(v));
      }));
      if (colDate) setColonneAxeX(colDate);
    } else if (colonneDansTitre) setColonneAxeX(colonneDansTitre);
    if (mesure) setColonneAxeY(mesure);
    setTypeGraphique(g.type === "Courbe" ? "Courbe" : "Barres");
    setAgregation(/répartition des enregistrements/i.test(titreN) ? "Nombre" : /moyenne/i.test(titreN) ? "Moyenne" : "Nombre");
    setSuggestionActive(g.id);
    setMessage("Suggestion chargée dans le générateur manuel : tu peux ajuster les axes, le type et l’agrégation avant de créer ta version.");
  }

  function construireGraphique() {
    setMessage("");
    if (!colonneAxeX) return;
    if (typeGraphique === "Carte") {
      compteur.current += 1;
      const carte: GraphiqueEpingle = { id: Date.now() * 1000 + compteur.current, titre: `Carte géographique — ${colonneAxeX}`, type: "Carte", labels: [], datasets: [{ label: "Occurrences", data: [], backgroundColor: "#9333ea", borderColor: "#7e22ce", borderWidth: 1 }] };
      setGraphiquesGeneres((prev) => [carte, ...prev]);
      setMessage("Carte ajoutée. Choisis la colonne géographique dans la carte affichée.");
      return;
    }
    const idxX = entetes.indexOf(colonneAxeX);
    const idxY = entetes.indexOf(colonneAxeY);
    const besoinY = !["Nombre", "Pourcentage"].includes(agregation);
    if (besoinY && idxY === -1) return;
    if (besoinY && !corps.some((ligne) => versNombre(ligne[idxY]) !== null)) {
      setMessage(`La colonne « ${colonneAxeY} » ne contient aucune valeur numérique exploitable. Choisis une colonne numérique ou « Nombre de lignes ».`);
      return;
    }

    const groupes = new Map<string, { somme: number; nNum: number; compte: number }>();
    for (const ligne of corps) {
      if (estValeurVide(ligne[idxX])) continue; // les lignes sans valeur en X sont ignorées
      const cle = String(ligne[idxX]).trim();
      const g = groupes.get(cle) ?? { somme: 0, nNum: 0, compte: 0 };
      g.compte += 1;
      if (besoinY) {
        const n = versNombre(ligne[idxY]); // cellules vides ou non numériques ignorées
        if (n !== null) {
          g.somme += n;
          g.nNum += 1;
        }
      }
      groupes.set(cle, g);
    }

    let paires = [...groupes.entries()].map(([label, g]) => {
      const valeurs = besoinY ? corps.filter((ligne) => !estValeurVide(ligne[idxX]) && String(ligne[idxX]).trim() === label)
        .map((ligne) => versNombre(ligne[idxY])).filter((n): n is number => n !== null) : [];
      const triees = [...valeurs].sort((a, b) => a - b);
      let valeur = g.compte;
      if (agregation === "Somme") valeur = g.somme;
      if (agregation === "Moyenne") valeur = g.nNum ? g.somme / g.nNum : 0;
      if (agregation === "Mediane") valeur = triees.length ? (triees.length % 2 ? triees[(triees.length - 1) / 2] : (triees[triees.length / 2 - 1] + triees[triees.length / 2]) / 2) : 0;
      if (agregation === "Minimum") valeur = triees.length ? triees[0] : 0;
      if (agregation === "Maximum") valeur = triees.length ? triees[triees.length - 1] : 0;
      if (agregation === "Valeurs distinctes") valeur = new Set(valeurs).size;
      return { label, valeur: arrondir(valeur), nNum: g.nNum };
    });
    if (agregation === "Pourcentage") {
      const total = paires.reduce((s, p) => s + p.valeur, 0);
      paires = paires.map((p) => ({ ...p, valeur: total ? arrondir((p.valeur / total) * 100) : 0 }));
    }

    if (besoinY && paires.every((p) => p.nNum === 0)) {
      setMessage(`La colonne « ${colonneAxeY} » ne contient aucune valeur numérique : choisis une autre colonne ou « Nombre ».`);
      return;
    }
    if (paires.length === 0) {
      setMessage(`La colonne « ${colonneAxeX} » ne contient aucune valeur exploitable.`);
      return;
    }

    if (typeGraphique !== "Courbe") paires.sort((a, b) => b.valeur - a.valeur);
    const limite = typeGraphique === "Camembert" ? MAX_PARTS_CAMEMBERT : MAX_CATEGORIES;
    if (paires.length > limite) {
      const gardes = paires.slice(0, limite);
      const reste = paires.slice(limite);
      if (typeGraphique === "Camembert" && agregation !== "Moyenne") {
        gardes.push({ label: "Autres", valeur: arrondir(reste.reduce((s, p) => s + p.valeur, 0)), nNum: 0 });
      }
      paires = gardes;
      setMessage(`Graphique limité aux ${limite} catégories principales (sur ${groupes.size}).`);
    }

    compteur.current += 1;
    const titreMesure = agregation === "Nombre" ? "Nombre de lignes" : agregation === "Pourcentage" ? "Pourcentage des lignes (%)" : `${agregation} — ${colonneAxeY}`;
    const nouveau: GraphiqueEpingle = {
      id: Date.now() * 1000 + compteur.current,
      titre: `${titreMesure} selon ${colonneAxeX}`,
      type: typeGraphique,
      labels: paires.map((p) => p.label),
      datasets: [
        {
          label: titreMesure,
          data: paires.map((p) => p.valeur),
          backgroundColor:
            typeGraphique === "Camembert" ? paires.map((_, i) => PALETTE[i % PALETTE.length]) : "#9333ea",
          borderColor: "#7e22ce",
          borderWidth: 1,
        },
      ],
    };
    setGraphiquesGeneres((prev) => [nouveau, ...prev]);
  }

  // Présentation Chart.js homogène : aucune modification du calcul des données.
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    resizeDelay: 120,
    animation: { duration: 650, easing: "easeOutQuart" as const },
    interaction: { mode: "index" as const, intersect: false },
    layout: { padding: { top: 8, right: 12, bottom: 4, left: 8 } },
    plugins: {
      legend: {
        display: true,
        position: "bottom" as const,
        labels: { usePointStyle: true, pointStyle: "circle" as const, boxWidth: 8, boxHeight: 8, padding: 18, color: "#64748b", font: { family: "Inter, ui-sans-serif, system-ui", size: 11, weight: 600 as const } },
      },
      tooltip: {
        enabled: true,
        backgroundColor: "#0f172a",
        titleColor: "#f8fafc",
        bodyColor: "#e2e8f0",
        borderColor: "#334155",
        borderWidth: 1,
        padding: 12,
        cornerRadius: 10,
        displayColors: true,
        usePointStyle: true,
      },
    },
    scales: {
      x: {
        border: { display: false },
        grid: { display: false },
        ticks: { color: "#64748b", maxRotation: 35, minRotation: 0, font: { family: "Inter, ui-sans-serif, system-ui", size: 10, weight: 500 as const } },
      },
      y: {
        beginAtZero: true,
        border: { display: false, dash: [4, 4] },
        grid: { color: "rgba(148,163,184,0.18)", tickLength: 0 },
        ticks: { color: "#64748b", padding: 10, font: { family: "Inter, ui-sans-serif, system-ui", size: 10, weight: 500 as const } },
      },
    },
    elements: {
      bar: { borderRadius: 7, borderSkipped: false },
      line: { borderWidth: 3, tension: 0.32, capBezierPoints: true },
      point: { radius: 3, hoverRadius: 6, hitRadius: 10, borderWidth: 2, backgroundColor: "#ffffff" },
      arc: { borderWidth: 3, borderColor: "#ffffff", hoverOffset: 7 },
    },
  } as const;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6 shadow-sm">
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 rounded-full bg-purple-600"></div>
        <h3 className="text-base font-bold text-slate-900 dark:text-white">Générateur de Graphiques</h3>
      </div>

      <section className="space-y-4">
        <div>
          <h4 className="text-sm font-bold text-slate-900 dark:text-white">Graphiques recommandés automatiquement</h4>
          <p className="text-xs text-slate-500 mt-1">DATENZA sélectionne des visualisations utiles à partir des colonnes détectées. Tu peux toujours créer tes propres graphiques juste en dessous.</p>
        </div>
        {graphiquesRecommandes.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {graphiquesRecommandes.map((g, index) => {
              const tendance = /évolution|evolution|mensuelle/i.test(g.titre);
              const comparaison = /moyenne de .* par /i.test(g.titre);
              const repartition = /répartition des enregistrements/i.test(g.titre);
              const explication = tendance
                ? "Une colonne temporelle et une mesure numérique permettent de suivre la tendance mois par mois."
                : comparaison
                  ? "Compare la valeur moyenne entre les catégories pour repérer les écarts les plus importants."
                  : repartition
                    ? "Montre comment les enregistrements se répartissent entre les principales catégories."
                    : "Regroupe une mesure numérique en classes pour observer sa distribution, sans afficher chaque valeur brute.";
              const niveau = tendance ? "Très pertinent" : comparaison ? "Pertinent" : repartition ? "Utile" : "Exploratoire";
              return (
              <div key={g.id} className={`min-w-0 bg-white dark:bg-slate-900 border rounded-2xl p-5 space-y-4 shadow-sm hover:shadow-md transition-shadow duration-200 ${suggestionActive === g.id ? "border-cyan-400 ring-2 ring-cyan-100 dark:ring-cyan-950/50" : "border-slate-200/80 dark:border-slate-700/80"}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-cyan-50 text-cyan-800 dark:bg-cyan-950/50 dark:text-cyan-300 text-xs font-bold">{index + 1}</span>
                      <span className="text-[10px] font-semibold rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 px-2 py-1">{niveau}</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">{g.titre}</h4>
                  </div>
                  <span className="shrink-0 text-[10px] font-semibold rounded-full bg-cyan-50 text-cyan-800 dark:bg-cyan-950/40 dark:text-cyan-300 px-2 py-1">{g.type === "Courbe" ? "Tendance" : "Comparaison"}</span>
                </div>
                <p className="text-xs leading-5 text-slate-500 dark:text-slate-400">{explication}</p>
                <div className="h-72 rounded-xl bg-gradient-to-b from-slate-50/80 to-white dark:from-slate-800/40 dark:to-slate-900 p-2">
                  {g.type === "Courbe" || g.type === "Aires" ? <Line data={g} options={{ ...options, elements: { ...options.elements, line: { ...options.elements.line, fill: g.type === "Aires" } } }} /> : <Bar data={g} options={options} />}
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button onClick={() => personnaliserSuggestion(g)} className="text-[11px] font-semibold text-slate-700 hover:text-cyan-800 dark:text-slate-200 dark:hover:text-cyan-300 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-lg">Personnaliser</button>
                  {onEpingler && <button onClick={() => onEpingler(g)} className="text-[11px] font-semibold text-cyan-700 hover:text-cyan-900 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-900/50 px-3 py-1.5 rounded-lg">★ Ajouter au tableau de bord</button>}
                </div>
              </div>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-slate-500 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-4">Aucune combinaison assez pertinente n’a été détectée automatiquement. Tu peux utiliser le générateur manuel ci-dessous.</p>
        )}
      </section>

      <div className="border-t border-slate-200 dark:border-slate-800 pt-5">
        <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-3">Créer un graphique personnalisé</h4>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200/60 dark:border-slate-700/50">
        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Type de graphique</label>
          <select value={typeGraphique} onChange={(e) => setTypeGraphique(e.target.value as TypeGraphique)} className={selectClasse}>
            <option value="Barres">Barres</option>
            <option value="Courbe">Courbe</option>
            <option value="Camembert">Camembert</option>
            <option value="Anneau">Anneau (doughnut)</option>
            <option value="Radar">Radar</option>
            <option value="Aires">Courbe avec aire</option>
            <option value="Carte">Carte géographique</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Axe X (catégories)</label>
          <select value={colonneAxeX} onChange={(e) => setColonneAxeX(e.target.value)} className={selectClasse}>
            {entetes.map((nom) => (
              <option key={nom} value={nom}>{nom}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Axe Y (valeurs)</label>
          <select
            value={colonneAxeY}
            onChange={(e) => setColonneAxeY(e.target.value)}
            disabled={entetes.length === 0}
            className={`${selectClasse} disabled:opacity-50`}
          >
            {entetes.map((nom) => (
              <option key={nom} value={nom}>{nom}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Agrégation</label>
          <select value={agregation} onChange={(e) => setAgregation(e.target.value as Agregation)} className={selectClasse}>
            <option value="Nombre">Nombre de lignes</option>
            <option value="Somme">Somme</option>
            <option value="Moyenne">Moyenne</option>
            <option value="Mediane">Médiane</option>
            <option value="Minimum">Minimum</option>
            <option value="Maximum">Maximum</option>
            <option value="Valeurs distinctes">Valeurs distinctes</option>
            <option value="Pourcentage">Pourcentage du total</option>
          </select>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={construireGraphique}
          className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-medium text-xs rounded-lg shadow transition"
        >
          + Ajouter le graphique
        </button>
        {message && <span className="text-xs text-amber-600 dark:text-amber-400">{message}</span>}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 pt-4">
        {graphiquesGeneres.map((g) => (
          <div
            key={g.id}
            className="min-w-0 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700/80 rounded-2xl p-5 space-y-4 shadow-sm hover:shadow-md transition-shadow duration-200"
          >
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{g.titre}</h4>
              <div className="flex shrink-0 gap-2">
                {onEpingler && (
                  <button
                    onClick={() => onEpingler(g)}
                    className="text-[11px] font-semibold text-purple-600 hover:text-purple-700 border border-purple-200 dark:border-purple-900/50 bg-purple-50 dark:bg-purple-950/30 px-2.5 py-1 rounded-md transition"
                  >
                    ★ Ajouter au tableau de bord
                  </button>
                )}
                <button
                  onClick={() => setGraphiquesGeneres((prev) => prev.filter((x) => x.id !== g.id))}
                  aria-label="Supprimer le graphique"
                  className="text-slate-400 hover:text-rose-600 text-sm px-1"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className={`${g.type === "Carte" ? "min-h-[360px]" : "h-80"} min-w-0 flex items-center justify-center rounded-xl bg-gradient-to-b from-slate-50/80 to-white dark:from-slate-800/40 dark:to-slate-900 p-2`}>
              {g.type === "Carte" && <div className="w-full min-h-[360px]"><CarteGeographique entetes={entetes} corps={corps} /></div>}
              {g.type === "Barres" && <Bar data={g} options={options} />}
              {(g.type === "Courbe" || g.type === "Aires") && <Line data={g} options={{ ...options, elements: { ...options.elements, line: { ...options.elements.line, fill: g.type === "Aires" } } }} />}
              {g.type === "Camembert" && <Pie data={g} options={options} />}
              {g.type === "Anneau" && <Doughnut data={g} options={{ ...options, cutout: "68%" }} />}
              {g.type === "Radar" && <Radar data={g} options={{ ...options, scales: { r: { angleLines: { color: "rgba(148,163,184,0.22)" }, grid: { color: "rgba(148,163,184,0.22)" }, pointLabels: { color: "#64748b", font: { size: 10, weight: 500 as const } }, ticks: { backdropColor: "transparent", color: "#94a3b8", showLabelBackdrop: false } } } }} />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
