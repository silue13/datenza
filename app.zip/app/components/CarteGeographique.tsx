"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import "leaflet/dist/leaflet.css";
import { trouverLieuCI, cleGeo } from "../../lib/geoci/data";
import type { Cellule } from "../../lib/analyse/utils";

const MapContainer = dynamic(() => import("react-leaflet").then((m) => m.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import("react-leaflet").then((m) => m.TileLayer), { ssr: false });
const CircleMarker = dynamic(() => import("react-leaflet").then((m) => m.CircleMarker), { ssr: false });
const Popup = dynamic(() => import("react-leaflet").then((m) => m.Popup), { ssr: false });
const AjusterVue = dynamic(() => import("./AjusterVue"), { ssr: false });

interface Props {
  entetes: string[];
  corps: Cellule[][];
}

interface PointLocalise {
  nom: string;
  lat: number;
  lng: number;
  total: number;
}
type AgregationCarte = "Nombre" | "Somme" | "Moyenne";
function nombreCellule(v: Cellule): number | null {
  if (v === null || v === undefined || String(v).trim() === "") return null;
  const n = Number(String(v).trim().replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

const MAX_LIEUX = 40; // Nominatim : 1 requête/seconde maximum, on limite donc le nombre de lieux inconnus
const RE_GEO = /(pays|country|ville|city|region|departement|department|commune|localite|locality|village|prefecture|district|province|quartier|adresse|lieu|location|aeroport|airport)/;

const pause = (ms: number) => new Promise((r) => setTimeout(r, ms));

export default function CarteGeographique({ entetes, corps }: Props) {
  const defaut = useMemo(() => entetes.find((h) => RE_GEO.test(cleGeo(h))) ?? "", [entetes]);
  const [choix, setChoix] = useState<string | null>(null);
  const colonnesNumeriques = useMemo(() => entetes.filter((h, i) => corps.some(l => nombreCellule(l[i]) !== null)), [entetes, corps]);
  const [colonneMesure, setColonneMesure] = useState<string>(colonnesNumeriques[0] || "");
  const [agregation, setAgregation] = useState<AgregationCarte>("Nombre");
  const [choixTypeLieu, setChoixTypeLieu] = useState("Cercles proportionnels");
  const colonneGeo = choix !== null && entetes.includes(choix) ? choix : defaut;
  // lieu -> coordonnées trouvées via Nominatim (null = introuvable)
  const [externes, setExternes] = useState<Record<string, { lat: number; lng: number } | null>>({});
  const demandes = useRef(new Set<string>());

  // Agrégation par lieu selon les paramètres choisis.
  const decompte = useMemo(() => {
    const idx = entetes.indexOf(colonneGeo);
    if (idx === -1) return [] as [string, number][];
    const idxMesure = entetes.indexOf(colonneMesure);
    const m = new Map<string, { somme: number; n: number; compte: number }>();
    for (const ligne of corps) {
      const v = String(ligne[idx] ?? "").trim();
      if (!v) continue;
      const g = m.get(v) ?? { somme: 0, n: 0, compte: 0 };
      g.compte++;
      if (agregation !== "Nombre" && idxMesure >= 0) { const n = nombreCellule(ligne[idxMesure]); if (n !== null) { g.somme += n; g.n++; } }
      m.set(v, g);
    }
    return [...m.entries()].map(([nom, g]) => [nom, agregation === "Nombre" ? g.compte : agregation === "Moyenne" ? (g.n ? g.somme / g.n : 0) : g.somme] as [string, number]).sort((a, b) => b[1] - a[1]).slice(0, MAX_LIEUX);
  }, [entetes, corps, colonneGeo, colonneMesure, agregation]);

  const inconnus = useMemo(() => decompte.map(([nom]) => nom).filter((nom) => !trouverLieuCI(nom)), [decompte]);

  // Géocodage Nominatim des lieux absents du référentiel, un par seconde, annulable.
  useEffect(() => {
    let annule = false;
    async function executer() {
      for (const nom of inconnus) {
        if (annule) return;
        if (demandes.current.has(nom)) continue;
        demandes.current.add(nom);
        let resultat: { lat: number; lng: number } | null = null;
        try {
          // Référentiel ivoirien d'abord (trouverLieuCI), puis recherche mondiale pour tout autre lieu ou pays.
          const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(nom)}`;
          const res = await fetch(url);
          if (res.ok) {
            const data = (await res.json()) as { lat: string; lon: string }[];
            if (data.length > 0) resultat = { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
          }
        } catch {
          resultat = null;
        }
        setExternes((prev) => ({ ...prev, [nom]: resultat })); // on garde le résultat même si la liste a changé
        await pause(1100);
      }
    }
    void executer();
    return () => {
      annule = true;
    };
  }, [inconnus]);

  const { points, nonLocalises, enAttente } = useMemo(() => {
    const pts: PointLocalise[] = [];
    let manques = 0;
    let attente = 0;
    for (const [nom, total] of decompte) {
      const local = trouverLieuCI(nom);
      if (local) {
        pts.push({ nom, lat: local[0], lng: local[1], total });
      } else if (nom in externes) {
        const e = externes[nom];
        if (e) pts.push({ nom, lat: e.lat, lng: e.lng, total });
        else manques++;
      } else {
        attente++;
      }
    }
    return { points: pts, nonLocalises: manques, enAttente: attente };
  }, [decompte, externes]);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="text-purple-600 text-base">🗺️</span>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Carte géographique{colonneGeo ? ` — ${colonneGeo}` : ""}
          </h3>
        </div>

        <div className="flex flex-wrap gap-2">
        <select aria-label="Colonne géographique"
          value={colonneGeo}
          onChange={(e) => setChoix(e.target.value)}
          className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-medium"
        >
          {colonneGeo === "" && <option value="">Choisir une colonne…</option>}
          {entetes.map((h) => (
            <option key={h} value={h}>{h}</option>
          ))}
        </select>
        <select aria-label="Agrégation de la carte" value={agregation} onChange={e => { const valeur = e.target.value as AgregationCarte; setAgregation(valeur); if (valeur !== "Nombre" && !colonneMesure && colonnesNumeriques.length) setColonneMesure(colonnesNumeriques[0]); }} className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-medium">
          <option value="Nombre">Nombre d’enregistrements</option><option value="Somme" disabled={!colonnesNumeriques.length}>Somme d’une mesure</option><option value="Moyenne" disabled={!colonnesNumeriques.length}>Moyenne d’une mesure</option>
        </select>
        {agregation !== "Nombre" && <select aria-label="Colonne de mesure" value={colonneMesure} onChange={e => setColonneMesure(e.target.value)} className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-medium">{colonnesNumeriques.map(h => <option key={h} value={h}>{h}</option>)}</select>}
        <select aria-label="Style des points" value={choixTypeLieu} onChange={e => setChoixTypeLieu(e.target.value)} className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-medium"><option>Cercles proportionnels</option><option>Points uniformes</option></select>
        </div>
      </div>

      {colonneGeo === "" ? (
        <p className="text-xs text-slate-500">
          Aucune colonne géographique détectée automatiquement (région, ville, commune, pays…). Choisis-en une dans la liste.
        </p>
      ) : (
        <div className="h-80 w-full rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 relative">
          <MapContainer center={[7.54, -5.55]} zoom={6} scrollWheelZoom={false} className="h-full w-full">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <AjusterVue points={points} />
            {points.map((p) => (
              <CircleMarker
                key={p.nom}
                center={[p.lat, p.lng]}
                radius={choixTypeLieu === "Points uniformes" ? 8 : Math.min(8 + Math.sqrt(Math.max(0, p.total)) * 2, 28)}
                pathOptions={{ fillColor: "#8b5cf6", color: "#6d28d9", weight: 2, fillOpacity: 0.65 }}
              >
                <Popup>
                  <div className="text-xs font-semibold p-1">
                    <p className="text-purple-700 font-bold">{p.nom}</p>
                    <p>{agregation === "Nombre" ? `${p.total} enregistrement(s)` : `${p.total.toLocaleString("fr-FR", { maximumFractionDigits: 2 })} — ${agregation.toLowerCase()} de ${colonneMesure}`}</p>
                  </div>
                </Popup>
              </CircleMarker>
            ))}
          </MapContainer>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pt-1">
        <span className="font-medium text-slate-600 dark:text-slate-400">
          {points.length} lieu(x) localisé(s)
          {nonLocalises > 0 && ` • ${nonLocalises} non localisé(s)`}
          {enAttente > 0 && ` • ${enAttente} en cours de recherche…`}
        </span>
        <div className="flex gap-3 overflow-x-auto">
          {[...points].sort((a, b) => b.total - a.total).slice(0, 5).map((p, i) => (
            <span key={p.nom} className="font-semibold text-slate-700 dark:text-slate-300 whitespace-nowrap">
              {i + 1}. {p.nom} — <strong className="text-purple-600">{p.total.toLocaleString("fr-FR", { maximumFractionDigits: 2 })}</strong>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}