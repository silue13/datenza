"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import "leaflet/dist/leaflet.css";
import { Sparkles, MapPin, Presentation } from "lucide-react";
import { trouverLieuCI, cleGeo, GEO_CI_EXHAUSTIF, PAYS_DU_MONDE } from "../../lib/geoci/data";
import { parseNombre, type Cellule, estValeurVide } from "../../lib/analyse/utils";
import { useData } from "../context/DataContext";

const MapContainer = dynamic(() => import("react-leaflet").then((m) => m.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import("react-leaflet").then((m) => m.TileLayer), { ssr: false });
const CircleMarker = dynamic(() => import("react-leaflet").then((m) => m.CircleMarker), { ssr: false });
const Popup = dynamic(() => import("react-leaflet").then((m) => m.Popup), { ssr: false });
const Tooltip = dynamic(() => import("react-leaflet").then((m) => m.Tooltip), { ssr: false });
const AjusterVue = dynamic(() => import("./AjusterVue"), { ssr: false });

interface Props {
  entetes: string[];
  corps: Cellule[][];
  onAjouterPptx?: (element: any) => void;
}

interface PointComparatif {
  nom: string;
  lat: number;
  lng: number;
  totalGlobal: number;
  valeursParSource: Record<string, number>;
  leader: string;
  valeurLeader: number;
  amplitude: number;
  ecartVsRef: number;
  variationPctVsRef: number;
}

type AgregationCarte = "Nombre" | "Somme" | "Moyenne";

function nombreCellule(v: Cellule): number | null {
  if (estValeurVide(v)) return null;
  return parseNombre(v);
}

const MAX_LIEUX = 80;

const MOTS_CLES_GEO = /(ville|city|commune|region|pays|country|departement|department|district|station|adresse|lieu|location|zone|secteur|territoire|localite|village|prefecture|province|quartier)/i;
const MOTS_CLES_EXCLUS = /(categorie|category|statut|status|mois|month|annee|year|commercial|vendeur|client|devise|type|produit|article|id|num|reference|ref|remise|taux)/i;

const COULEURS_COMPARAISON = [
  { fill: "#2563eb", border: "#1d4ed8" }, // Cobalt
  { fill: "#0891b2", border: "#0e7490" }, // Cyan
  { fill: "#d97706", border: "#b45309" }, // Ambre
  { fill: "#059669", border: "#047857" }, // Emeraude
  { fill: "#dc2626", border: "#b91c1c" }, // Rouge
  { fill: "#7c3aed", border: "#6d28d9" }, // Violet
];

const pause = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Garde-fou frontalier strict de la Côte d'Ivoire
function estDansFrontieresCI(lat: number, lng: number): boolean {
  return lat >= 4.2 && lat <= 10.9 && lng >= -8.7 && lng <= -2.4;
}

export default function CarteGeographique({ entetes, corps, onAjouterPptx }: Props) {
  const { graphiquesEpingles, epinglerGraphique } = useData();

  const estModeComparaison = entetes.includes("Fichier Source");
  const idxSource = entetes.indexOf("Fichier Source");

  const sourcesFichiers = useMemo(() => {
    if (!estModeComparaison || idxSource === -1) return [];
    return Array.from(new Set(corps.map((l) => String(l[idxSource] ?? "").trim()).filter(Boolean)));
  }, [estModeComparaison, idxSource, corps]);

  const estBenchmarkActif = estModeComparaison && sourcesFichiers.length >= 2;

  const [sourceRefChoisie, setSourceRefChoisie] = useState<string>("");
  const refSource = sourcesFichiers.includes(sourceRefChoisie)
    ? sourceRefChoisie
    : sourcesFichiers[0] || "";

  // 1. Détection des colonnes géographiques
  const colonnesGeographiquesEligibles = useMemo(() => {
    return entetes.filter((nom, idx) => {
      if (nom === "Fichier Source") return false;

      const nomNorm = nom.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
      if (MOTS_CLES_EXCLUS.test(nomNorm)) return false;
      if (MOTS_CLES_GEO.test(nomNorm)) return true;

      const echantillon = corps.map((ligne) => ligne[idx]).filter((v) => !estValeurVide(v));
      if (echantillon.length === 0) return false;

      const nbNombres = echantillon.filter((v) => parseNombre(v) !== null).length;
      if (nbNombres / echantillon.length >= 0.5) return false;

      const echantillonTexte = echantillon.slice(0, 25).map((l) => String(l).trim());
      return echantillonTexte.some(
        (v) =>
          trouverLieuCI(v) !== null ||
          /abidjan|bouake|daloa|korhogo|san[- ]pedro|yamoussoukro|bélier|belier|gôh|goh|nawa|sassandra/i.test(v)
      );
    });
  }, [entetes, corps]);

  const defaut = useMemo(() => {
    const prioRegion = colonnesGeographiquesEligibles.find((h) => /(region|district)/i.test(h));
    if (prioRegion) return prioRegion;
    const prioVille = colonnesGeographiquesEligibles.find((h) => /(ville|commune|station)/i.test(h));
    if (prioVille) return prioVille;
    return colonnesGeographiquesEligibles[0] || "";
  }, [colonnesGeographiquesEligibles]);

  const [choix, setChoix] = useState<string | null>(null);
  const colonneGeo = choix !== null && colonnesGeographiquesEligibles.includes(choix) ? choix : defaut;

  const colonnesNumeriques = useMemo(() => {
    return entetes
      .filter((h) => h !== "Fichier Source")
      .filter((h) => {
        const i = entetes.indexOf(h);
        const vals = corps.map((l) => nombreCellule(l[i])).filter((n): n is number => n !== null);
        return vals.length >= 2;
      });
  }, [entetes, corps]);

  const [colonneMesure, setColonneMesure] = useState<string>(colonnesNumeriques[0] || "");
  const [agregation, setAgregation] = useState<AgregationCarte>("Somme");
  const [externes, setExternes] = useState<Record<string, { lat: number; lng: number } | null>>({});
  const demandes = useRef(new Set<string>());
  const [estDejaInclus, setEstDejaInclus] = useState(false);

  // 2. Détection du contexte territorial (verrouillé en CI dès qu'une région ivoirienne est reconnue)
  const contexteTerritorial = useMemo<"CI" | "MONDE">(() => {
    const idx = entetes.indexOf(colonneGeo);
    if (idx === -1) return "CI";

    const valeursLieux = corps.map((r) => String(r[idx] ?? "").trim());
    if (/pays|country/i.test(colonneGeo)) return "MONDE";

    const aIndicesCI = valeursLieux.some((v) => {
      const vClean = v.toLowerCase();
      return (
        trouverLieuCI(v) !== null ||
        /belier|bélier|sassandra|nawa|bandama|goh|gôh|lagunes|savanes|comoe|comoé|woroba|tonkpi|cavally|marahoue|marahoué|ag审neby|folon|hambol|poro|tchologo|bounkani/i.test(
          vClean
        )
      );
    });

    return aIndicesCI ? "CI" : "MONDE";
  }, [entetes, corps, colonneGeo]);

  // 3. Agrégation des données par zone
  const donneesAgregees = useMemo(() => {
    const idxGeo = entetes.indexOf(colonneGeo);
    if (idxGeo === -1) return [];

    const idxMesure = entetes.indexOf(colonneMesure);
    const mapLieux = new Map<
      string,
      {
        totalSomme: number;
        totalN: number;
        totalCompte: number;
        sources: Map<string, { somme: number; n: number; compte: number }>;
      }
    >();

    for (const ligne of corps) {
      const lieu = String(ligne[idxGeo] ?? "").replace(/["'«»“”]/g, "").trim();
      if (!lieu || lieu === "—" || lieu === "-" || /^total/i.test(lieu) || /^variation/i.test(lieu)) continue;

      const sourceActuelle =
        estModeComparaison && idxSource >= 0 ? String(ligne[idxSource] ?? "").trim() : "Defaut";

      let gLieu = mapLieux.get(lieu);
      if (!gLieu) {
        gLieu = { totalSomme: 0, totalN: 0, totalCompte: 0, sources: new Map() };
        mapLieux.set(lieu, gLieu);
      }

      gLieu.totalCompte++;
      let gSrc = gLieu.sources.get(sourceActuelle);
      if (!gSrc) {
        gSrc = { somme: 0, n: 0, compte: 0 };
        gLieu.sources.set(sourceActuelle, gSrc);
      }
      gSrc.compte++;

      if (agregation !== "Nombre" && idxMesure >= 0) {
        const val = nombreCellule(ligne[idxMesure]);
        if (val !== null) {
          gLieu.totalSomme += val;
          gLieu.totalN++;
          gSrc.somme += val;
          gSrc.n++;
        }
      }
    }

    const calculerValeurFinale = (g: { somme: number; n: number; compte: number }) => {
      if (agregation === "Nombre") return g.compte;
      if (agregation === "Moyenne") return g.n ? Math.round((g.somme / g.n) * 100) / 100 : 0;
      return Math.round(g.somme * 100) / 100;
    };

    setEstDejaInclus(false);

    return Array.from(mapLieux.entries())
      .map(([nom, gLieu]) => {
        const parSource: Record<string, number> = {};
        for (const [srcNom, gSrc] of gLieu.sources.entries()) {
          parSource[srcNom] = calculerValeurFinale(gSrc);
        }

        const totalGlobal = calculerValeurFinale({
          somme: gLieu.totalSomme,
          n: gLieu.totalN,
          compte: gLieu.totalCompte,
        });

        return { nom, totalGlobal, parSource };
      })
      .sort((a, b) => b.totalGlobal - a.totalGlobal)
      .slice(0, MAX_LIEUX);
  }, [entetes, corps, colonneGeo, colonneMesure, agregation, estModeComparaison, idxSource]);

  // 4. Résolution géographique locale
  function resoudreCoordonnees(nom: string): [number, number] | null {
    const coordCI = trouverLieuCI(nom);
    if (coordCI) return coordCI;

    const cle = cleGeo(nom);
    if (PAYS_DU_MONDE && PAYS_DU_MONDE[cle]) return PAYS_DU_MONDE[cle];

    return null;
  }

  const inconnus = useMemo(
    () => donneesAgregees.map((d) => d.nom).filter((nom) => !resoudreCoordonnees(nom)),
    [donneesAgregees]
  );

  // 5. Appel OpenStreetMap cadenassé sur la Côte d'Ivoire
  useEffect(() => {
    let annule = false;
    async function executer() {
      for (const nom of inconnus) {
        if (annule) return;
        if (demandes.current.has(nom)) continue;
        demandes.current.add(nom);

        let resultat: { lat: number; lng: number } | null = null;
        try {
          const paramPays = contexteTerritorial === "CI" ? "&countrycodes=ci" : "";
          const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(
            nom
          )}${paramPays}`;

          const res = await fetch(url, { headers: { "Accept-Language": "fr" } });
          if (res.ok) {
            const data = (await res.json()) as { lat: string; lon: string }[];
            if (data.length > 0) {
              const lat = parseFloat(data[0].lat);
              const lng = parseFloat(data[0].lon);

              // GARDE-FOU : On rejette tout point extérieur à la CI si on analyse la CI
              if (contexteTerritorial === "CI" && !estDansFrontieresCI(lat, lng)) {
                resultat = null;
              } else {
                resultat = { lat, lng };
              }
            }
          }
        } catch {
          resultat = null;
        }

        if (!annule) {
          setExternes((prev) => ({ ...prev, [nom]: resultat }));
        }
        await pause(1000);
      }
    }
    void executer();
    return () => {
      annule = true;
    };
  }, [inconnus, contexteTerritorial]);

  // 6. Construction des points finaux
  const points = useMemo<PointComparatif[]>(() => {
    const pts: PointComparatif[] = [];

    for (const d of donneesAgregees) {
      let coord = resoudreCoordonnees(d.nom);
      if (!coord && externes[d.nom]) {
        coord = [externes[d.nom]!.lat, externes[d.nom]!.lng];
      }

      if (!coord) continue;

      // ÉLIMINATION FORMELLE DES POINTS HORS LIMITES (ex: Bélier en Namibie)
      if (contexteTerritorial === "CI" && !estDansFrontieresCI(coord[0], coord[1])) {
        continue;
      }

      let leader = sourcesFichiers[0] || "Général";
      let maxVal = -Infinity;
      let minVal = Infinity;

      sourcesFichiers.forEach((src) => {
        const v = d.parSource[src] || 0;
        if (v > maxVal) {
          maxVal = v;
          leader = src;
        }
        if (v < minVal) {
          minVal = v;
        }
      });

      const valeurLeader = maxVal === -Infinity ? 0 : maxVal;
      const amplitude = Math.round((valeurLeader - (minVal === Infinity ? 0 : minVal)) * 100) / 100;
      const vRef = d.parSource[refSource] || 0;
      const ecartVsRef = Math.round((valeurLeader - vRef) * 100) / 100;
      const variationPctVsRef = vRef > 0 ? Math.round((ecartVsRef / vRef) * 1000) / 10 : 0;

      pts.push({
        nom: d.nom,
        lat: coord[0],
        lng: coord[1],
        totalGlobal: d.totalGlobal,
        valeursParSource: d.parSource,
        leader,
        valeurLeader,
        amplitude,
        ecartVsRef,
        variationPctVsRef,
      });
    }

    return pts;
  }, [donneesAgregees, externes, sourcesFichiers, refSource, contexteTerritorial]);

  const maxValMesure = useMemo(() => {
    if (!points.length) return 1;
    let m = 0;
    points.forEach((p) => {
      if (p.totalGlobal > m) m = p.totalGlobal;
    });
    return m || 1;
  }, [points]);

  const rayonPoint = (val: number) => {
    const ratio = Math.max(0, val / maxValMesure);
    return Math.round(8 + ratio * 24);
  };

  const centreCI: [number, number] = [7.54, -5.55];
  const zoomCI = 6.8;

  const idGraphiqueCarte = `carte-geo-${colonneGeo}-${agregation}-${colonneMesure || "compte"}`;
  const estInclusPptx =
    (graphiquesEpingles || []).some((g) => String(g.id) === String(idGraphiqueCarte)) || estDejaInclus;

  const preparerExportPptx = () => {
    if (!points.length || !onAjouterPptx) return;
    const topPoints = points.slice(0, 10);
    const labels = topPoints.map((p) => p.nom);

    const objetExport = {
      id: idGraphiqueCarte,
      titre: `Synthèse Territoriale : ${agregation} de ${colonneMesure || "volumes"} par ${colonneGeo}`,
      type: "Barres",
      chartType: "bar",
      labels,
      datasets: [
        {
          label: agregation === "Nombre" ? "Effectifs" : `${agregation} — ${colonneMesure}`,
          data: topPoints.map((p) => p.totalGlobal),
          backgroundColor: "#2563eb",
          borderColor: "#1d4ed8",
        },
      ],
      interpretation: `Répartition spatiale sur les principaux territoires.\n\nPôle dominant : « ${topPoints[0]?.nom || ""} » avec ${topPoints[0]?.totalGlobal.toLocaleString("fr-FR")}.`,
    };

    onAjouterPptx(objetExport as any);
    if (epinglerGraphique) epinglerGraphique(objetExport as any);
    setEstDejaInclus(true);
  };

  return (
    <div className="bloc-carte-print print-eviter-coupure bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
      {/* En-tête */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {estBenchmarkActif
                ? `Cartographie Comparative des Territoires (${sourcesFichiers.length} fichiers)`
                : `Carte géographique — ${colonneGeo}`}
            </h3>
            <p className="text-xs text-slate-400">
              {estBenchmarkActif
                ? "Confrontation géographique multi-sources (cercles concentriques imbriqués)"
                : "Répartition spatiale et concentration territoriale"}
            </p>
          </div>
        </div>

        {/* Contrôles interactifs */}
        <div className="no-print print:hidden flex flex-wrap items-center gap-2">
          {estBenchmarkActif && (
            <select
              value={refSource}
              onChange={(e) => setSourceRefChoisie(e.target.value)}
              className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-lg p-2 text-xs font-bold text-blue-700 dark:text-blue-300"
            >
              {sourcesFichiers.map((s) => (
                <option key={s} value={s}>
                  Réf : {s}
                </option>
              ))}
            </select>
          )}

          <select
            value={colonneGeo}
            onChange={(e) => setChoix(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-semibold text-slate-700 dark:text-slate-300"
          >
            {colonnesGeographiquesEligibles.map((h) => (
              <option key={h} value={h}>
                {h}
              </option>
            ))}
          </select>

          <select
            value={agregation}
            onChange={(e) => setAgregation(e.target.value as AgregationCarte)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-medium"
          >
            <option value="Somme" disabled={!colonnesNumeriques.length}>
              Somme cumulée
            </option>
            <option value="Moyenne" disabled={!colonnesNumeriques.length}>
              Moyenne
            </option>
            <option value="Nombre">Nombre d’enregistrements</option>
          </select>

          {agregation !== "Nombre" && (
            <select
              value={colonneMesure}
              onChange={(e) => setColonneMesure(e.target.value)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-medium"
            >
              {colonnesNumeriques.map((h) => (
                <option key={h} value={h}>
                  {h}
                </option>
              ))}
            </select>
          )}

          <button
            onClick={preparerExportPptx}
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition shrink-0 cursor-pointer ${
              estInclusPptx
                ? "bg-blue-600 text-white shadow-xs"
                : "bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800"
            }`}
          >
            <Presentation className="w-3.5 h-3.5" />
            {estInclusPptx ? "✓ Inclus au PPTX" : "+ Ajouter au PPTX"}
          </button>
        </div>
      </div>

      {/* Rendu Leaflet sécurisé (AjusterVue reçoit points directement) */}
      <div className="h-72 sm:h-96 w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 relative z-0">
        <MapContainer
          center={centreCI}
          zoom={zoomCI}
          scrollWheelZoom={false}
          dragging={typeof window !== "undefined" && window.innerWidth > 768}
          touchZoom={false}
          className="h-full w-full"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          <AjusterVue points={points} />

          {/* Points cartographiques avec Tooltip au survol UNIQUEMENT (non permanent) */}
          {points.map((p) => {
            const r = rayonPoint(p.totalGlobal);

            return (
              <CircleMarker
                key={p.nom}
                center={[p.lat, p.lng]}
                radius={r}
                pathOptions={{
                  fillColor: "#2563eb",
                  color: "#1d4ed8",
                  weight: 2,
                  fillOpacity: 0.65,
                }}
              >
                {/* TOOLTIP INTERACTIF AU SURVOL : Disparaît quand on quitte la zone */}
                <Tooltip direction="top" offset={[0, -r - 2]} opacity={0.95}>
                  <div className="text-xs font-bold font-sans text-slate-900 leading-tight">
                    <span>{p.nom}</span>
                    <span className="block font-black text-blue-600 mt-0.5">
                      {p.totalGlobal.toLocaleString("fr-FR")} {agregation === "Nombre" ? "lignes" : ""}
                    </span>
                  </div>
                </Tooltip>

                <Popup>
                  <div className="text-xs font-sans space-y-1 p-1">
                    <p className="font-bold text-slate-900 text-sm border-b pb-1">{p.nom}</p>
                    <p className="text-slate-600 pt-1">
                      {agregation} :{" "}
                      <strong className="text-blue-600">
                        {p.totalGlobal.toLocaleString("fr-FR")}
                      </strong>
                    </p>
                  </div>
                </Popup>
              </CircleMarker>
            );
          })}
        </MapContainer>
      </div>

      {/* Ruban des zones localisées sous la carte */}
      <div className="space-y-1.5 pt-1 text-xs">
        <span className="font-bold text-slate-600 dark:text-slate-300">
          {points.length} zone(s) localisée(s) :
        </span>
        <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1 scrollbar-thin">
          {points.map((p) => (
            <span
              key={p.nom}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[11px]"
            >
              <span className="w-2 h-2 rounded-full bg-blue-600"></span>
              <strong>{p.nom}</strong> :{" "}
              <span className="text-blue-600 dark:text-blue-400 font-bold font-mono">
                {p.totalGlobal.toLocaleString("fr-FR")}
              </span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}