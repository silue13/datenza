"use client";
import { type ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import Link from "next/link";
import { useData } from "../context/DataContext";
import GraphiqueGenerateur from "../components/GraphiqueGenerateur";
import CarteGeographique from "../components/CarteGeographique";
import TableauCroiseDynamique from "../components/TableauCroiseDynamique";

interface Cat { total: number; nbCategoriesDistinctes: number; topValeurs: { valeur: string; effectif: number; pourcentage: number }[] }
interface Num { n: number; moyenne: number | null; mediane: number | null; min: number | null; max: number | null; atypiques: number }
interface Boo { vrai: number; faux: number }
interface Dat { n: number; min: string | null; max: string | null }
interface Ident { distincts: number; unicite: number }

const carte = "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm";
const fmt = (v: number | null | undefined) => (v === null || v === undefined ? "—" : v.toLocaleString("fr-FR"));

export default function AnalysePage() {
  const { nomFichier, entetes, corps, resultat, rapport, epinglerGraphique } = useData();


  if (corps.length === 0) {
    return (
      <div className="max-w-4xl mx-auto py-16 text-center space-y-4">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Analyse</h1>
        <p className="text-slate-500 text-sm">
          Aucun fichier n&apos;a été importé. Veuillez d&apos;abord charger un fichier Excel ou CSV sur l&apos;accueil.
        </p>
      </div>
    );
  }

  if (!resultat) {
    return (
      <div className="max-w-4xl mx-auto py-16 text-center space-y-4">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Analyse</h1>
        <p className="text-slate-500 text-sm">
          Choisis les colonnes à analyser sur l&apos;accueil, puis clique sur « Lancer l&apos;analyse ».
        </p>
        <Link href="/" className="inline-block rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-semibold text-white">
          Retour à l&apos;accueil
        </Link>
      </div>
    );
  }

  const noms = Object.keys(resultat.statistiques);
  const correlations = [...resultat.correlations].sort((a, b) => Math.abs(b.coefficient) - Math.abs(a.coefficient));

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-16 text-slate-800 dark:text-slate-100 font-sans">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-3xl font-black tracking-tight text-purple-700 dark:text-purple-400">DATENZA</h1>
        <p className="text-xl font-extrabold text-slate-800 dark:text-slate-200">Rapport d&apos;analyse des données</p>
        <p className="text-xs text-slate-500 mt-1">
          <strong className="text-slate-700 dark:text-slate-300">{nomFichier}</strong> — Généré le{" "}
          {new Date().toLocaleDateString("fr-FR")} à {new Date().toLocaleTimeString("fr-FR")}
        </p>
      </div>


      <Depliant titre="Synthèse" detail={`${rapport.length} points clés`}>
        <ul className="space-y-2.5 text-sm leading-relaxed">
          {rapport.map((b, i) => (
            <li key={i} className="border-b border-slate-100 dark:border-slate-800 pb-2.5 last:border-0">{b.texte}</li>
          ))}
        </ul>
      </Depliant>

      <Depliant titre="Statistiques par colonne" detail={`${noms.length} colonnes`}>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {noms.map((nom) => {
            const info = resultat.statistiques[nom];
            const s = info.stats;
            return (
              <div key={nom} className={`${carte} p-4 space-y-2`}>
                <div className="flex justify-between items-center gap-2 border-b pb-2 border-slate-100 dark:border-slate-800">
                  <span className="font-bold text-sm truncate">{nom}</span>
                  <span className="text-[10px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-500 whitespace-nowrap">
                    {info.type}
                  </span>
                </div>
                <div className="text-xs space-y-1.5 pt-1">
                  {info.type === "numerique" && (() => {
                    const n = s as unknown as Num;
                    return (
                      <>
                        <Ligne l="Moyenne" v={fmt(n.moyenne)} />
                        <Ligne l="Médiane" v={fmt(n.mediane)} />
                        <Ligne l="Min / Max" v={`${fmt(n.min)} / ${fmt(n.max)}`} />
                        {n.atypiques > 0 && <Ligne l="Valeurs atypiques" v={fmt(n.atypiques)} />}
                        {info.tendance && <Ligne l="Tendance" v={info.tendance.direction} />}
                      </>
                    );
                  })()}
                  {info.type === "categorielle" && (() => {
                    const c = s as unknown as Cat;
                    return (
                      <>
                        <p className="text-[10px] text-slate-400">{fmt(c.total)} valeurs — {fmt(c.nbCategoriesDistinctes)} catégories</p>
                        {c.topValeurs.map((t, i) => (
                          <Ligne key={t.valeur} l={t.valeur} v={`${fmt(t.effectif)} (${t.pourcentage} %)`} fort={i === 0} />
                        ))}
                      </>
                    );
                  })()}
                  {info.type === "booleen" && (() => {
                    const b = s as unknown as Boo;
                    return (
                      <>
                        <Ligne l="Oui" v={fmt(b.vrai)} />
                        <Ligne l="Non" v={fmt(b.faux)} />
                      </>
                    );
                  })()}
                  {info.type === "date" && (() => {
                    const d = s as unknown as Dat;
                    return (
                      <>
                        <Ligne l="Du" v={d.min ? d.min.slice(0, 10) : "—"} />
                        <Ligne l="Au" v={d.max ? d.max.slice(0, 10) : "—"} />
                      </>
                    );
                  })()}
                  {info.type === "identifiant" && (() => {
                    const d = s as unknown as Ident;
                    return (
                      <>
                        <Ligne l="Valeurs distinctes" v={fmt(d.distincts)} />
                        <Ligne l="Unicité" v={`${d.unicite} %`} />
                      </>
                    );
                  })()}
                  <Ligne l="Remplissage" v={`${info.tauxRemplissage} %`} />
                </div>
              </div>
            );
          })}
        </div>
      </Depliant>

      {correlations.length > 0 && (
        <div className={`${carte} p-6 space-y-3`}>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Corrélations</h2>
          <p className="text-xs text-slate-500">
            Une corrélation ne prouve pas une causalité. Les cellules vides sont ignorées dans le calcul.
          </p>
          <ul className="text-sm space-y-1.5">
            {correlations.slice(0, 10).map((c) => (
              <li key={`${c.colonneA}|${c.colonneB}`} className="flex justify-between gap-3">
                <span>{c.colonneA} ↔ {c.colonneB}</span>
                <span className="font-semibold">r = {c.coefficient} <span className="font-normal text-slate-500">({c.interpretation})</span></span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <GraphiqueGenerateur key={`g-${nomFichier}`} entetes={entetes} corps={corps} onEpingler={epinglerGraphique} />
      <CarteGeographique key={`c-${nomFichier}`} entetes={entetes} corps={corps} />
      <TableauCroiseDynamique key={`t-${nomFichier}`} entetes={entetes} corps={corps} />
    </div>
  );
}

/** Bloc fermé par défaut : le contenu ne s'affiche qu'au clic sur le titre. */
function Depliant({ titre, detail, children }: { titre: string; detail: string; children: ReactNode }) {
  return (
    <details className={`group ${carte}`}>
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 rounded-2xl px-6 py-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 [&::-webkit-details-marker]:hidden">
        <span className="flex items-baseline gap-3">
          <span className="text-lg font-bold text-slate-900 dark:text-white">{titre}</span>
          <span className="text-xs text-slate-500">{detail}</span>
        </span>
        <ChevronDown className="h-5 w-5 shrink-0 text-slate-400 transition-transform group-open:rotate-180" aria-hidden />
      </summary>
      <div className="border-t border-slate-100 px-6 py-5 dark:border-slate-800">{children}</div>
    </details>
  );
}

function Ligne({ l, v, fort }: { l: string; v: string; fort?: boolean }) {
  return (
    <div className={`flex justify-between gap-3 ${fort ? "font-bold text-purple-600 dark:text-purple-400" : "text-slate-600 dark:text-slate-400"}`}>
      <span className="truncate">{l}</span>
      <span className="whitespace-nowrap font-semibold">{v}</span>
    </div>
  );
}