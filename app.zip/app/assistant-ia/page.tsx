"use client";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import { useData } from "../context/DataContext";
import { analyserColonnes } from "../../lib/analyse/analyse";
import { construireContexte } from "../../lib/analyse/context";
import { calculerTdcAvecLimite, type Agregation } from "../../lib/analyse/tdc";
import type { Cellule } from "../../lib/analyse/utils";
import TableTdc from "../components/TableTdc";
import { enregistrerFournisseur, lireFournisseur } from "../../lib/prefs";

interface Message {
  role: "user" | "assistant";
  text: string;
  via?: string;
}

const AGGS: Record<string, Agregation> = {
  count: "nombre", compte: "nombre", nombre: "nombre",
  sum: "somme", somme: "somme",
  average: "moyenne", avg: "moyenne", moyenne: "moyenne",
  min: "min", minimum: "min", max: "max", maximum: "max",
};

const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();

type TdcCalcule =
  | { erreur: string }
  | { titre: string; donnees: ReturnType<typeof calculerTdcAvecLimite>["donnees"]; agg: Agregation; lignes: string[]; nbValeurs: number };

function calculerTdcIA(json: string, entetes: string[], corps: Cellule[][]): TdcCalcule {
  try {
    const o = JSON.parse(json) as { title?: string; titre?: string; lignes?: string[]; colonnes?: string[]; valeurs?: string[]; agregation?: string };
    const trouver = (noms: unknown) =>
      (Array.isArray(noms) ? noms : []).map((n) => entetes.find((e) => norm(e) === norm(String(n)))).filter((x): x is string => !!x);
    const lignes = trouver(o.lignes);
    const colonnes = trouver(o.colonnes);
    const valeurs = trouver(o.valeurs);
    const demandees = (o.lignes?.length ?? 0) + (o.colonnes?.length ?? 0) + (o.valeurs?.length ?? 0);
    if (lignes.length === 0 || lignes.length + colonnes.length + valeurs.length < demandees) {
      return { erreur: "une ou plusieurs colonnes demandées n'existent pas dans le fichier" };
    }
    if (lignes.some((c) => colonnes.includes(c))) return { erreur: "une colonne ne peut pas être à la fois en lignes et en colonnes" };
    const agg = AGGS[norm(o.agregation ?? "nombre")] ?? "nombre";
    const r = calculerTdcAvecLimite({ entetes, corps }, lignes, colonnes, valeurs, agg);
    return { titre: o.title ?? o.titre ?? "Tableau croisé dynamique", donnees: r.donnees, agg, lignes, nbValeurs: valeurs.length };
  } catch (e) {
    return { erreur: e instanceof Error ? e.message : "bloc illisible" };
  }
}

/** Bloc technique « DATENZA_TDC: {...} » émis par l'IA : le tableau est calculé ici, jamais par l'IA. */
function TdcIA({ json, entetes, corps }: { json: string; entetes: string[]; corps: Cellule[][] }) {
  const r = calculerTdcIA(json, entetes, corps);
  if ("erreur" in r) return <p className="text-rose-600">TDC non généré : {r.erreur}.</p>;
  return (
    <div className="my-3 space-y-2">
      <p className="font-bold text-purple-700 dark:text-purple-300">{r.titre}</p>
      <TableTdc donnees={r.donnees} agregation={r.agg} titreLignes={r.lignes.join(" / ")} plusieursValeurs={r.nbValeurs > 1} />
      <p className="text-[10px] text-slate-400">Calculé par le moteur DATENZA à partir des données du fichier.</p>
    </div>
  );
}

const H = ({ children }: { children?: ReactNode }) => (
  <h4 className="text-xs font-bold mt-3 mb-1 text-purple-700 dark:text-purple-300">{children}</h4>
);
const BORD = "border border-slate-300 dark:border-slate-600 px-2 py-1";
const MD: Components = {
  h1: H, h2: H, h3: H, h4: H,
  p: ({ children }) => <p className="my-1.5">{children}</p>,
  ul: ({ children }) => <ul className="list-disc pl-5 my-1.5 space-y-0.5">{children}</ul>,
  ol: ({ children }) => <ol className="list-decimal pl-5 my-1.5 space-y-0.5">{children}</ol>,
  strong: ({ children }) => <strong className="font-semibold text-slate-900 dark:text-white">{children}</strong>,
  hr: () => <hr className="my-3 border-slate-300 dark:border-slate-600" />,
  table: ({ children }) => <div className="overflow-x-auto my-2"><table className="text-[11px] border-collapse">{children}</table></div>,
  th: ({ children }) => <th className={`${BORD} text-left font-semibold bg-slate-200 dark:bg-slate-700`}>{children}</th>,
  td: ({ children }) => <td className={BORD}>{children}</td>,
};

function ReponseIA({ texte, entetes, corps }: { texte: string; entetes: string[]; corps: Cellule[][] }) {
  // Le split garde le JSON des lignes « DATENZA_TDC: {...} » aux positions impaires ; le reste est du Markdown.
  const morceaux = texte.split(/^\s*DATENZA_TDC\s*:\s*(\{.*\})\s*$/im);
  return (
    <>
      {morceaux.map((p, i) =>
        i % 2 === 1 ? (
          <TdcIA key={i} json={p} entetes={entetes} corps={corps} />
        ) : (
          p.trim() && <ReactMarkdown key={i} remarkPlugins={[remarkGfm]} components={MD}>{p}</ReactMarkdown>
        )
      )}
    </>
  );
}

export default function AssistantIAPage() {
  const { nomFichier, corps, entetes, resultat } = useData();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [chargement, setChargement] = useState(false);
  const [fournisseur, setFournisseur] = useState("auto");
  const [dispo, setDispo] = useState<{ id: string; nom: string }[]>([]);

  // Moteurs configurés côté serveur ; si le choix mémorisé n'existe plus, retour au mode automatique.
  useEffect(() => {
    fetch("/api/ai")
      .then((r) => r.json())
      .then((d: { fournisseurs?: { id: string; nom: string }[] }) => {
        const liste = d.fournisseurs ?? [];
        setDispo(liste);
        const memorise = lireFournisseur();
        setFournisseur(liste.some((f) => f.id === memorise) ? memorise : "auto");
      })
      .catch(() => {});
  }, []);

  // Contexte envoyé à l'IA : résumés statistiques + 8 premières lignes (jamais le fichier complet).
  const contexte = useMemo(() => {
    if (corps.length === 0) return "";
    const res = resultat ?? analyserColonnes(entetes, corps, entetes);
    return JSON.stringify(construireContexte(nomFichier, entetes, corps, res));
  }, [nomFichier, entetes, corps, resultat]);

  async function envoyerQuestion() {
    const question = input.trim();
    if (!question || chargement) return;
    if (corps.length === 0) {
      setMessages((p) => [...p, { role: "assistant", text: "Veuillez d'abord importer un fichier sur la page d'accueil." }]);
      return;
    }
    const historique = messages.slice(-12).map((m) => ({ role: m.role, content: m.text }));
    setMessages((p) => [...p, { role: "user", text: question }]);
    setInput("");
    setChargement(true);
    try {
      const rep = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, contexte, historique, fournisseur, langueConversation: "auto", langueApp: "fr" }),
      });
      const data = (await rep.json().catch(() => ({}))) as { reponse?: string; fournisseur?: string; error?: string };
      if (!rep.ok || !data.reponse) throw new Error(data.error ?? `Erreur ${rep.status}`);
      setMessages((p) => [...p, { role: "assistant", text: data.reponse as string, via: data.fournisseur }]);
    } catch (e) {
      setMessages((p) => [...p, { role: "assistant", text: `⚠ ${e instanceof Error ? e.message : "Impossible d'obtenir une réponse."}` }]);
    } finally {
      setChargement(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 font-sans">
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-purple-600">DATENZA INTELLIGENCE</span>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white mt-0.5">Assistant IA</h1>
        <p className="text-slate-500 text-sm">Interrogez directement vos données en langage naturel.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl h-[560px] flex flex-col shadow-sm overflow-hidden">
        <div className="px-6 py-2.5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2 text-xs">
          <label htmlFor="moteur-ia" className="text-slate-500">Moteur IA</label>
          <select
            id="moteur-ia"
            value={fournisseur}
            onChange={(e) => {
              setFournisseur(e.target.value);
              enregistrerFournisseur(e.target.value);
            }}
            className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="auto">Automatique (recommandé)</option>
            {dispo.map((f) => (
              <option key={f.id} value={f.id}>{f.nom}</option>
            ))}
          </select>
        </div>
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          <div className="flex justify-start">
            <div className="max-w-[85%] p-4 rounded-2xl rounded-bl-none text-xs leading-relaxed bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
              {corps.length === 0
                ? "Bonjour ! Importez d'abord un fichier sur la page d'accueil, puis posez-moi vos questions sur vos données."
                : `Bonjour ! Le fichier « ${nomFichier} » (${corps.length} lignes) est chargé. Posez-moi vos questions : répartitions, anomalies, tendances, tableaux croisés…`}
            </div>
          </div>
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed shadow-sm ${
                  m.role === "user"
                    ? "bg-purple-600 text-white rounded-br-none whitespace-pre-wrap"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-none"
                }`}
              >
                {m.role === "assistant" ? (
                  <>
                    <ReponseIA texte={m.text} entetes={entetes} corps={corps} />
                    {m.via && (
                      <p className="mt-2 text-[10px] text-slate-400">
                        Réponse générée par {dispo.find((f) => f.id === m.via)?.nom ?? m.via}
                      </p>
                    )}
                  </>
                ) : (
                  m.text
                )}
              </div>
            </div>
          ))}
          {chargement && (
            <div className="flex justify-start">
              <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-2xl text-xs text-purple-600 animate-pulse font-medium">
                DATENZA IA analyse le jeu de données…
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void envoyerQuestion()}
            placeholder="Posez votre question sur le fichier…"
            className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <button
            onClick={() => void envoyerQuestion()}
            disabled={chargement || !input.trim()}
            className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white font-semibold text-xs rounded-xl shadow transition"
          >
            Envoyer
          </button>
        </div>
      </div>
    </div>
  );
}