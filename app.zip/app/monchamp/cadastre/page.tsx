"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  LIBELLE_EAU,
  LIBELLE_SOL,
  basculerEau,
  contourSeCroise,
  contourValide,
  formaterCoord,
  historiqueParcelle,
  centre,
  superficieHa,
  type AccesEau,
  type Coord,
  type ParcelleCadastre,
  type TypeSol,
} from "../../../lib/monchamp/cadastre";
import type { Campagne } from "../../../lib/monchamp/calculs";
import type { Travail } from "../../../lib/monchamp/qg";
import { enregistrerDonnees, lireDonnees } from "../../../lib/monchamp/stockage";
import { creerFormateurs } from "../../../lib/analyse/format";
import CarteParcelles, { type Fond } from "../../components/CarteParcelles";

const carte = "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm";
const champ =
  "w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm";
const bouton = "rounded-xl bg-purple-600 px-3 py-2 text-xs font-semibold text-white hover:bg-purple-700 disabled:opacity-50";
const boutonClair =
  "rounded-xl border border-slate-300 dark:border-slate-700 px-3 py-2 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50";
const f = creerFormateurs("fr");

type Message = { type: "info" | "alerte" | "erreur"; texte: string } | null;
const COULEUR_MESSAGE = {
  info: "text-emerald-700 dark:text-emerald-300",
  alerte: "text-amber-700 dark:text-amber-300",
  erreur: "text-rose-600",
};

const arrondir2 = (v: number) => Math.round(v * 100) / 100;

export default function CadastrePage() {
  const [parcelles, setParcelles] = useState<ParcelleCadastre[]>([]);
  const [campagnes, setCampagnes] = useState<Campagne[]>([]);
  const [travaux, setTravaux] = useState<Travail[]>([]);
  const [pret, setPret] = useState(false);
  const [selectionId, setSelectionId] = useState<number | null>(null);
  const [trace, setTrace] = useState<Coord[] | null>(null);
  const [fond, setFond] = useState<Fond>("satellite");
  const [message, setMessage] = useState<Message>(null);
  const [gpsEnCours, setGpsEnCours] = useState(false);

  const [aAnnee, setAAnnee] = useState("");
  const [aCulture, setACulture] = useState("");
  const [aNote, setANote] = useState("");

  useEffect(() => {
    const d = lireDonnees();
    setParcelles(d.parcelles);
    setCampagnes(d.campagnes);
    setTravaux(d.travaux);
    setSelectionId(d.parcelles[0]?.id ?? null);
    setPret(true);
  }, []);

  useEffect(() => {
    if (pret) enregistrerDonnees({ parcelles, campagnes, travaux });
  }, [parcelles, campagnes, travaux, pret]);

  const sel = parcelles.find((p) => p.id === selectionId) ?? null;
  const contourSel = sel && contourValide(sel.contour) ? sel.contour : null;
  const mesuree = contourSel ? superficieHa(contourSel) : null;
  const apercu = trace && trace.length >= 3 ? superficieHa(trace) : null;
  const traceSeCroise = trace ? contourSeCroise(trace) : false;
  const historique = useMemo(() => (sel ? historiqueParcelle(sel, campagnes) : []), [sel, campagnes]);
  const nbTracees = parcelles.filter((p) => contourValide(p.contour)).length;

  const majParcelle = (id: number, patch: Partial<ParcelleCadastre>) =>
    setParcelles((l) => l.map((p) => (p.id === id ? { ...p, ...patch } : p)));

  function ajouterPositionGps() {
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      return setMessage({ type: "erreur", texte: "La localisation GPS n'est pas disponible sur cet appareil ou ce navigateur." });
    }
    setGpsEnCours(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsEnCours(false);
        const c: Coord = [pos.coords.latitude, pos.coords.longitude];
        setTrace((t) => (t ? [...t, c] : [c]));
        const precision = Math.round(pos.coords.accuracy);
        setMessage(
          precision > 20
            ? { type: "alerte", texte: `Point ajouté, mais la précision n'est que de ± ${precision} m. Attends un peu en plein air, puis recommence si besoin.` }
            : { type: "info", texte: `Point ajouté (précision ± ${precision} m).` }
        );
      },
      (err) => {
        setGpsEnCours(false);
        setMessage({
          type: "erreur",
          texte: err.code === 1 ? "Autorisation de localisation refusée : autorise-la dans les réglages du navigateur." : "Position introuvable pour le moment. Réessaie à l'extérieur.",
        });
      },
      { enableHighAccuracy: true, timeout: 20_000, maximumAge: 0 }
    );
  }

  function terminerTrace() {
    if (!sel || !trace || trace.length < 3) return;
    if (contourSeCroise(trace)) {
      return setMessage({ type: "erreur", texte: "Le contour se croise : la superficie serait fausse. Annule le dernier point ou abandonne et recommence." });
    }
    majParcelle(sel.id, { contour: trace });
    setMessage({ type: "info", texte: `Contour enregistré : ${f.nombre(arrondir2(superficieHa(trace)))} ha mesurés.` });
    setTrace(null);
  }

  function ajouterAntecedent() {
    const annee = Number(aAnnee);
    if (!sel || !aCulture.trim() || !Number.isInteger(annee) || annee < 1950 || annee > new Date().getFullYear() + 1) {
      return setMessage({ type: "erreur", texte: "Antécédent : indique une année valide et la culture." });
    }
    const id = Math.max(0, ...(sel.antecedents ?? []).map((a) => a.id)) + 1;
    majParcelle(sel.id, { antecedents: [...(sel.antecedents ?? []), { id, annee, culture: aCulture.trim(), note: aNote.trim() || undefined }] });
    setMessage(null);
    setACulture("");
    setANote("");
  }

  if (!pret) return null;

  if (parcelles.length === 0) {
    return (
      <div className="max-w-3xl mx-auto py-16 text-center space-y-4">
        <h1 className="text-2xl font-bold">Cadastre</h1>
        <p className="text-sm text-slate-500">Aucune parcelle pour le moment. Ajoute-en une dans MonChamp, puis reviens la cartographier.</p>
        <Link href="/monchamp" className="inline-block rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-semibold text-white">
          Aller à MonChamp
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16 text-slate-800 dark:text-slate-100">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-purple-700 dark:text-purple-400">Cadastre de l&apos;exploitation</h1>
          <p className="text-sm text-slate-500 mt-1">
            {parcelles.length} parcelle(s), dont {nbTracees} avec contour GPS. Les données restent dans ce navigateur.
          </p>
        </div>
        <div className="flex gap-2">
          <button className={fond === "satellite" ? bouton : boutonClair} onClick={() => setFond("satellite")}>Satellite</button>
          <button className={fond === "plan" ? bouton : boutonClair} onClick={() => setFond("plan")}>Plan</button>
        </div>
      </div>

      {message && <p className={`text-sm ${COULEUR_MESSAGE[message.type]}`}>{message.texte}</p>}

      <div className="grid lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 space-y-3">
          <CarteParcelles
            parcelles={parcelles}
            selectionId={selectionId}
            trace={trace}
            fond={fond}
            cleVue={`${selectionId ?? "tout"}-${trace === null ? "vue" : "trace"}`}
            onClic={(c) => setTrace((t) => (t ? [...t, c] : [c]))}
            onSelection={(id) => setSelectionId(id)}
          />
          {trace !== null ? (
            <div className={`${carte} p-4 space-y-3`}>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                <strong>Tracé en cours — {trace.length} point(s).</strong> Touche la carte pour poser chaque coin de la parcelle, ou marche le long du
                bord et ajoute ta position GPS à chaque coin.
                {apercu !== null && ` Superficie actuelle : ${f.nombre(arrondir2(apercu))} ha.`}
              </p>
              {traceSeCroise && <p className="text-xs text-rose-600">Le contour se croise : retire le dernier point.</p>}
              <div className="flex flex-wrap gap-2">
                <button className={boutonClair} onClick={ajouterPositionGps} disabled={gpsEnCours}>
                  {gpsEnCours ? "Recherche du GPS…" : "Ajouter ma position GPS"}
                </button>
                <button className={boutonClair} onClick={() => setTrace((t) => (t ? t.slice(0, -1) : t))} disabled={trace.length === 0}>
                  Annuler le dernier point
                </button>
                <button className={bouton} onClick={terminerTrace} disabled={trace.length < 3 || traceSeCroise}>
                  Terminer le contour
                </button>
                <button className={boutonClair} onClick={() => { setTrace(null); setMessage(null); }}>Abandonner</button>
              </div>
            </div>
          ) : (
            sel && (
              <div className="flex flex-wrap gap-2">
                <button className={bouton} onClick={() => { setTrace([]); setMessage(null); }}>
                  {contourSel ? "Retracer le contour" : "Tracer le contour"} de « {sel.nom} »
                </button>
                {contourSel && (
                  <button className={boutonClair} onClick={() => { majParcelle(sel.id, { contour: undefined }); setMessage(null); }}>
                    Supprimer le contour
                  </button>
                )}
              </div>
            )
          )}
          {fond === "satellite" && (
            <p className="text-[10px] text-slate-400">
              Dans certaines zones rurales l&apos;imagerie satellite est ancienne ou peu détaillée à fort zoom : bascule sur « Plan » si l&apos;image est floue.
            </p>
          )}
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className={`${carte} p-4 space-y-2`}>
            <h2 className="font-bold text-sm">Parcelles</h2>
            <ul className="space-y-1">
              {parcelles.map((p) => (
                <li key={p.id}>
                  <button
                    disabled={trace !== null}
                    onClick={() => setSelectionId(p.id)}
                    className={`w-full text-left rounded-xl px-3 py-2 text-xs flex items-center justify-between disabled:opacity-60 ${
                      p.id === selectionId ? "bg-purple-100/70 dark:bg-purple-950/50 font-semibold" : "hover:bg-slate-100 dark:hover:bg-slate-800"
                    }`}
                  >
                    <span>{p.nom} · {f.nombre(p.superficieHa)} ha</span>
                    <span className={contourValide(p.contour) ? "text-emerald-600" : "text-slate-400"}>
                      {contourValide(p.contour) ? "contour tracé" : "à tracer"}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {sel && (
            <div className={`${carte} p-4 space-y-4`}>
              <div>
                <h2 className="font-bold">{sel.nom}</h2>
                <p className="text-xs text-slate-500">{sel.localite || "Localité non renseignée"}</p>
              </div>

              <div className="text-xs space-y-1">
                <p>Superficie enregistrée : <strong>{f.nombre(sel.superficieHa)} ha</strong></p>
                {mesuree !== null && (
                  <>
                    <p>Mesurée sur la carte : <strong>{f.nombre(arrondir2(mesuree))} ha</strong></p>
                    {Math.abs(mesuree - sel.superficieHa) / sel.superficieHa > 0.01 && (
                      <button className={boutonClair} onClick={() => majParcelle(sel.id, { superficieHa: arrondir2(mesuree) })}>
                        Utiliser la superficie mesurée
                      </button>
                    )}
                    {contourSel && centre(contourSel) && (
                      <p className="text-slate-500">Centre : {formaterCoord(centre(contourSel) as Coord)}</p>
                    )}
                    <p className="text-[10px] text-slate-400">
                      Mesure indicative : un GPS de téléphone est précis à quelques mètres. Elle ne remplace pas un levé de géomètre ni un titre foncier.
                    </p>
                  </>
                )}
              </div>

              <label className="block text-xs space-y-1">
                <span className="font-semibold">Type de sol</span>
                <select
                  className={champ}
                  value={sel.sol ?? ""}
                  onChange={(e) => majParcelle(sel.id, { sol: (e.target.value || undefined) as TypeSol | undefined })}
                >
                  <option value="">Non renseigné</option>
                  {(Object.keys(LIBELLE_SOL) as TypeSol[]).map((k) => (
                    <option key={k} value={k}>{LIBELLE_SOL[k]}</option>
                  ))}
                </select>
              </label>

              <fieldset className="text-xs space-y-1">
                <legend className="font-semibold mb-1">Accès à l&apos;eau</legend>
                {(Object.keys(LIBELLE_EAU) as AccesEau[]).map((k) => (
                  <label key={k} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={(sel.eau ?? []).includes(k)}
                      onChange={() => majParcelle(sel.id, { eau: basculerEau(sel.eau ?? [], k) })}
                    />
                    {LIBELLE_EAU[k]}
                  </label>
                ))}
              </fieldset>

              <div className="text-xs space-y-2">
                <p className="font-semibold">Historique d&apos;exploitation</p>
                {historique.length === 0 ? (
                  <p className="text-slate-500">Rien d&apos;enregistré. Ajoute ce qui a été cultivé avant que tu utilises MonChamp.</p>
                ) : (
                  <ul className="space-y-1">
                    {historique.map((h) => (
                      <li key={h.cle} className="flex items-start justify-between gap-2">
                        <span>
                          <strong>{h.annee}</strong> — {h.culture}
                          {h.source === "campagne" &&
                            (h.enCours ? " (campagne en cours)" : ` · ${f.nombre(h.quantiteKg ?? 0)} kg récoltés`)}
                          {h.note && <span className="text-slate-500"> · {h.note}</span>}
                        </span>
                        {h.source === "antecedent" && (
                          <button
                            className="text-rose-600 shrink-0"
                            onClick={() => majParcelle(sel.id, { antecedents: (sel.antecedents ?? []).filter((a) => a.id !== h.antecedentId) })}
                          >
                            Supprimer
                          </button>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
                <div className="grid grid-cols-3 gap-2">
                  <input className={champ} placeholder="Année" inputMode="numeric" value={aAnnee} onChange={(e) => setAAnnee(e.target.value)} />
                  <input className={`${champ} col-span-2`} placeholder="Culture (ex. Igname)" value={aCulture} onChange={(e) => setACulture(e.target.value)} />
                  <input className={`${champ} col-span-3`} placeholder="Note (facultatif) : jachère, brûlis, engrais…" value={aNote} onChange={(e) => setANote(e.target.value)} />
                </div>
                <button className={boutonClair} onClick={ajouterAntecedent}>Ajouter à l&apos;historique</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}