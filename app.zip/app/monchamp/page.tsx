"use client";
import { useEffect, useMemo, useState } from "react";
import {
  bilanGlobal,
  bilanParCulture,
  estRecoltee,
  margePourcent,
  marge,
  recette,
  rendementKgHa,
  type Campagne,
  type EtatParcelle,
  type Parcelle,
  type StatutCampagne,
} from "../../lib/monchamp/calculs";
import { formaterJour, jourISO, jourValide, type Priorite, type Travail } from "../../lib/monchamp/qg";
import { enregistrerDonnees, lireDonnees } from "../../lib/monchamp/stockage";
import { creerFormateurs } from "../../lib/analyse/format";
import QGExploitant from "../components/QGExploitant";

const carte = "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm";
const champ =
  "w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm";
const bouton = "rounded-xl bg-purple-600 px-4 py-2 text-xs font-semibold text-white hover:bg-purple-700 disabled:opacity-50";
const f = creerFormateurs("fr");
const num = (s: string) => {
  const n = Number(s.trim().replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) && n >= 0 ? n : NaN;
};

export default function MonChampPage() {
  const [parcelles, setParcelles] = useState<Parcelle[]>([]);
  const [campagnes, setCampagnes] = useState<Campagne[]>([]);
  const [travaux, setTravaux] = useState<Travail[]>([]);
  const [pret, setPret] = useState(false);
  const [aujourdhui, setAujourdhui] = useState(""); // renseigné côté navigateur pour éviter un écart serveur/client
  const [erreur, setErreur] = useState("");

  const [pNom, setPNom] = useState("");
  const [pLoc, setPLoc] = useState("");
  const [pSup, setPSup] = useState("");
  const [pEtat, setPEtat] = useState<"" | EtatParcelle>("");

  const [cParcelle, setCParcelle] = useState("");
  const [cCulture, setCCulture] = useState("");
  const [cAnnee, setCAnnee] = useState(String(new Date().getFullYear()));
  const [cStatut, setCStatut] = useState<StatutCampagne>("recoltee");
  const [cDatePrevue, setCDatePrevue] = useState("");
  const [cQte, setCQte] = useState("");
  const [cPrix, setCPrix] = useState("");
  const [cCharges, setCCharges] = useState("");

  const [tParcelle, setTParcelle] = useState("");
  const [tLibelle, setTLibelle] = useState("");
  const [tEcheance, setTEcheance] = useState("");
  const [tPriorite, setTPriorite] = useState<Priorite>("normale");

  useEffect(() => {
    const d = lireDonnees();
    setParcelles(d.parcelles);
    setCampagnes(d.campagnes);
    setTravaux(d.travaux);
    setAujourdhui(jourISO());
    setPret(true);
  }, []);

  useEffect(() => {
    if (pret) enregistrerDonnees({ parcelles, campagnes, travaux });
  }, [parcelles, campagnes, travaux, pret]);

  const global = useMemo(() => bilanGlobal(campagnes), [campagnes]);
  const parCulture = useMemo(() => bilanParCulture(campagnes, parcelles), [campagnes, parcelles]);
  const nid = (liste: { id: number }[]) => Math.max(0, ...liste.map((x) => x.id)) + 1;
  const nomParcelle = (id: number | null) =>
    id === null ? "Toute l'exploitation" : (parcelles.find((p) => p.id === id)?.nom ?? "—");

  function ajouterParcelle() {
    const sup = num(pSup);
    if (!pNom.trim() || !(sup > 0)) return setErreur("Parcelle : indique un nom et une superficie en hectares supérieure à 0.");
    setErreur("");
    setParcelles((p) => [
      ...p,
      { id: nid(p), nom: pNom.trim(), localite: pLoc.trim(), superficieHa: sup, etat: pEtat || undefined },
    ]);
    setPNom("");
    setPLoc("");
    setPSup("");
    setPEtat("");
  }

  function ajouterCampagne() {
    const enCours = cStatut === "en_cours";
    const qte = num(cQte), prix = num(cPrix), charges = num(cCharges), annee = Number(cAnnee);
    if (!cParcelle || !cCulture.trim() || [qte, prix, charges].some(Number.isNaN) || !(annee > 1990))
      return setErreur("Campagne : choisis une parcelle et renseigne culture, année, quantité, prix et charges (nombres positifs).");
    if (enCours && !jourValide(cDatePrevue)) return setErreur("Campagne en cours : indique la date de récolte prévue.");
    if (!enCours && !(qte > 0)) return setErreur("Campagne récoltée : indique la quantité récoltée (kg).");
    setErreur("");
    setCampagnes((c) => [
      ...c,
      {
        id: nid(c),
        parcelleId: Number(cParcelle),
        culture: cCulture.trim(),
        annee,
        quantiteKg: enCours ? 0 : qte,
        prixKg: enCours ? 0 : prix,
        charges,
        statut: cStatut,
        dateRecoltePrevue: enCours ? cDatePrevue : undefined,
      },
    ]);
    setCCulture("");
    setCDatePrevue("");
    setCQte("");
    setCPrix("");
    setCCharges("");
  }

  function ajouterTravail() {
    if (!tLibelle.trim() || !jourValide(tEcheance)) return setErreur("Travail : indique ce qu'il faut faire et la date d'échéance.");
    setErreur("");
    setTravaux((t) => [
      ...t,
      { id: nid(t), parcelleId: tParcelle ? Number(tParcelle) : null, libelle: tLibelle.trim(), echeance: tEcheance, priorite: tPriorite, fait: false },
    ]);
    setTLibelle("");
    setTEcheance("");
  }

  function supprimerParcelle(id: number) {
    // campagnes et travaux d'une parcelle supprimée n'ont plus de sens : on les retire avec elle
    setParcelles((p) => p.filter((x) => x.id !== id));
    setCampagnes((c) => c.filter((x) => x.parcelleId !== id));
    setTravaux((t) => t.filter((x) => x.parcelleId !== id));
  }

  function basculerTravail(id: number, fait: boolean) {
    setTravaux((t) => t.map((x) => (x.id === id ? { ...x, fait } : x)));
  }

  function marquerRecoltee(id: number) {
    const c = campagnes.find((x) => x.id === id);
    if (!c) return;
    const q = window.prompt(`Quantité récoltée (kg) pour ${c.culture} ?`);
    if (q === null) return;
    const p = window.prompt("Prix de vente (FCFA/kg) ? Mets 0 si tu ne sais pas encore.", "0");
    if (p === null) return;
    const qte = num(q), prix = num(p);
    if (Number.isNaN(qte) || !(qte > 0) || Number.isNaN(prix)) return setErreur("Récolte : indique une quantité supérieure à 0 et un prix valide.");
    setErreur("");
    setCampagnes((l) =>
      l.map((x) => (x.id === id ? { ...x, statut: "recoltee", quantiteKg: qte, prixKg: prix, dateRecoltePrevue: undefined } : x))
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-16 text-slate-800 dark:text-slate-100">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-3xl font-black tracking-tight text-purple-700 dark:text-purple-400">MonChamp</h1>
        <p className="text-sm text-slate-500 mt-1">
          Pilotage de ton exploitation : parcelles, travaux, campagnes et marge. Les données restent dans ce navigateur.
        </p>
      </div>

      {erreur && <p className="text-sm text-rose-600">{erreur}</p>}

      {pret && aujourdhui && (
        <QGExploitant
          parcelles={parcelles}
          campagnes={campagnes}
          travaux={travaux}
          aujourdhui={aujourdhui}
          onTravailFait={(id) => basculerTravail(id, true)}
          onRecoltee={marquerRecoltee}
        />
      )}

      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          ["Recettes (campagnes récoltées)", f.prix(global.recettes)],
          ["Charges", f.prix(global.charges)],
          ["Marge", f.prix(global.marge)],
          ["Marge / recettes", global.margePct === null ? "—" : f.pourcent(global.margePct)],
        ].map(([titre, valeur]) => (
          <div key={titre} className={`${carte} p-4`}>
            <p className="text-[11px] uppercase tracking-wide text-slate-500">{titre}</p>
            <p className="text-lg font-extrabold mt-1">{valeur}</p>
          </div>
        ))}
      </section>

      <section className="grid lg:grid-cols-3 gap-6">
        <div className={`${carte} p-5 space-y-3`}>
          <h2 className="font-bold">Ajouter une parcelle</h2>
          <input className={champ} placeholder="Nom (ex. Bas-fond)" value={pNom} onChange={(e) => setPNom(e.target.value)} />
          <input className={champ} placeholder="Localité (ex. Korhogo)" value={pLoc} onChange={(e) => setPLoc(e.target.value)} />
          <input className={champ} placeholder="Superficie (hectares)" inputMode="decimal" value={pSup} onChange={(e) => setPSup(e.target.value)} />
          <select className={champ} value={pEtat} onChange={(e) => setPEtat(e.target.value as "" | EtatParcelle)}>
            <option value="">État du terrain : non évalué</option>
            <option value="bon">État du terrain : bon</option>
            <option value="surveiller">État du terrain : à surveiller</option>
            <option value="probleme">État du terrain : problème</option>
          </select>
          <button className={bouton} onClick={ajouterParcelle}>Ajouter la parcelle</button>
        </div>

        <div className={`${carte} p-5 space-y-3`}>
          <h2 className="font-bold">Ajouter une campagne</h2>
          <select className={champ} value={cParcelle} onChange={(e) => setCParcelle(e.target.value)}>
            <option value="">Choisir une parcelle…</option>
            {parcelles.map((p) => (
              <option key={p.id} value={p.id}>{p.nom} ({f.nombre(p.superficieHa)} ha)</option>
            ))}
          </select>
          <select className={champ} value={cStatut} onChange={(e) => setCStatut(e.target.value as StatutCampagne)}>
            <option value="recoltee">Déjà récoltée</option>
            <option value="en_cours">En cours (récolte à venir)</option>
          </select>
          <div className="grid grid-cols-2 gap-3">
            <input className={champ} placeholder="Culture (ex. Maïs)" value={cCulture} onChange={(e) => setCCulture(e.target.value)} />
            <input className={champ} placeholder="Année" inputMode="numeric" value={cAnnee} onChange={(e) => setCAnnee(e.target.value)} />
            {cStatut === "en_cours" ? (
              <label className="col-span-2 text-[11px] text-slate-500 space-y-1 block">
                Date de récolte prévue
                <input type="date" className={champ} value={cDatePrevue} onChange={(e) => setCDatePrevue(e.target.value)} />
              </label>
            ) : (
              <>
                <input className={champ} placeholder="Récolte (kg)" inputMode="decimal" value={cQte} onChange={(e) => setCQte(e.target.value)} />
                <input className={champ} placeholder="Prix de vente (FCFA/kg)" inputMode="decimal" value={cPrix} onChange={(e) => setCPrix(e.target.value)} />
              </>
            )}
          </div>
          <input className={champ} placeholder="Charges (FCFA) : semences, engrais, main-d'œuvre…" inputMode="decimal" value={cCharges} onChange={(e) => setCCharges(e.target.value)} />
          <button className={bouton} onClick={ajouterCampagne} disabled={parcelles.length === 0}>Ajouter la campagne</button>
          {parcelles.length === 0 && <p className="text-[11px] text-slate-500">Ajoute d&apos;abord une parcelle.</p>}
        </div>

        <div className={`${carte} p-5 space-y-3`}>
          <h2 className="font-bold">Ajouter un travail</h2>
          <input className={champ} placeholder="Ex. Désherbage, semis, traitement…" value={tLibelle} onChange={(e) => setTLibelle(e.target.value)} />
          <select className={champ} value={tParcelle} onChange={(e) => setTParcelle(e.target.value)}>
            <option value="">Toute l&apos;exploitation</option>
            {parcelles.map((p) => (
              <option key={p.id} value={p.id}>{p.nom}</option>
            ))}
          </select>
          <div className="grid grid-cols-2 gap-3">
            <input type="date" className={champ} value={tEcheance} onChange={(e) => setTEcheance(e.target.value)} />
            <select className={champ} value={tPriorite} onChange={(e) => setTPriorite(e.target.value as Priorite)}>
              <option value="haute">Priorité haute</option>
              <option value="normale">Priorité normale</option>
              <option value="basse">Priorité basse</option>
            </select>
          </div>
          <button className={bouton} onClick={ajouterTravail}>Ajouter le travail</button>
        </div>
      </section>

      <section className={`${carte} p-5 space-y-3`}>
        <h2 className="font-bold">Parcelles</h2>
        {parcelles.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune parcelle pour le moment.</p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            {parcelles.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-2">
                <span><strong>{p.nom}</strong>{p.localite && ` — ${p.localite}`} · {f.nombre(p.superficieHa)} ha</span>
                <button className="text-xs text-rose-600" onClick={() => supprimerParcelle(p.id)}>Supprimer</button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className={`${carte} p-5 space-y-3`}>
        <h2 className="font-bold">Travaux</h2>
        {travaux.length === 0 ? (
          <p className="text-sm text-slate-500">Aucun travail enregistré.</p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
            {[...travaux].sort((a, b) => Number(a.fait) - Number(b.fait) || a.echeance.localeCompare(b.echeance)).map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 py-2">
                <span className={t.fait ? "line-through text-slate-400" : ""}>
                  <strong>{t.libelle}</strong> — {nomParcelle(t.parcelleId)} · {formaterJour(t.echeance)} · priorité {t.priorite}
                </span>
                <span className="flex gap-3 text-xs shrink-0">
                  <button className="text-purple-700 dark:text-purple-300" onClick={() => basculerTravail(t.id, !t.fait)}>
                    {t.fait ? "Rouvrir" : "Fait"}
                  </button>
                  <button className="text-rose-600" onClick={() => setTravaux((l) => l.filter((x) => x.id !== t.id))}>Supprimer</button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className={`${carte} p-5 space-y-3 overflow-x-auto`}>
        <h2 className="font-bold">Campagnes</h2>
        {campagnes.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune campagne enregistrée.</p>
        ) : (
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-slate-500">
                {["Culture", "Année", "Parcelle", "Rendement", "Recette", "Charges", "Marge", "Marge %", ""].map((h) => (
                  <th key={h} className="py-2 pr-3 font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...campagnes].sort((a, b) => b.annee - a.annee).map((c) => {
                const p = parcelles.find((x) => x.id === c.parcelleId);
                const finie = estRecoltee(c);
                const rdt = rendementKgHa(c, p);
                const mp = margePourcent(c);
                return (
                  <tr key={c.id} className="border-t border-slate-100 dark:border-slate-800">
                    <td className="py-2 pr-3 font-semibold">
                      {c.culture}
                      {!finie && (
                        <span className="ml-2 rounded-full bg-sky-100 text-sky-700 dark:bg-sky-950/50 dark:text-sky-300 px-2 py-0.5 text-[10px]">
                          en cours{c.dateRecoltePrevue ? ` · récolte ${formaterJour(c.dateRecoltePrevue)}` : ""}
                        </span>
                      )}
                    </td>
                    <td className="pr-3">{c.annee}</td>
                    <td className="pr-3">{p?.nom ?? "—"}</td>
                    <td className="pr-3">{finie && rdt !== null ? `${f.nombre(rdt)} kg/ha` : "—"}</td>
                    <td className="pr-3">{finie ? f.prix(recette(c)) : "—"}</td>
                    <td className="pr-3">{f.prix(c.charges)}</td>
                    <td className={`pr-3 font-semibold ${finie ? (marge(c) < 0 ? "text-rose-600" : "text-emerald-600") : ""}`}>{finie ? f.prix(marge(c)) : "—"}</td>
                    <td className="pr-3">{finie && mp !== null ? f.pourcent(mp) : "—"}</td>
                    <td className="whitespace-nowrap">
                      {!finie && <button className="mr-3 text-purple-700 dark:text-purple-300" onClick={() => marquerRecoltee(c.id)}>Récoltée</button>}
                      <button className="text-rose-600" onClick={() => setCampagnes((l) => l.filter((x) => x.id !== c.id))}>Supprimer</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </section>

      {parCulture.length > 0 && (
        <section className={`${carte} p-5 space-y-3 overflow-x-auto`}>
          <h2 className="font-bold">Bilan par culture</h2>
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-slate-500">
                {["Culture", "Campagnes", "Production", "Rendement moyen", "Recette", "Charges", "Marge"].map((h) => (
                  <th key={h} className="py-2 pr-3 font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {parCulture.map((g) => (
                <tr key={g.culture} className="border-t border-slate-100 dark:border-slate-800">
                  <td className="py-2 pr-3 font-semibold">{g.culture}</td>
                  <td className="pr-3">{g.nbCampagnes}</td>
                  <td className="pr-3">{f.nombre(g.quantiteKg)} kg</td>
                  <td className="pr-3">{g.rendementKgHa === null ? "—" : `${f.nombre(g.rendementKgHa)} kg/ha`}</td>
                  <td className="pr-3">{f.prix(g.recette)}</td>
                  <td className="pr-3">{f.prix(g.charges)}</td>
                  <td className={`pr-3 font-semibold ${g.marge < 0 ? "text-rose-600" : "text-emerald-600"}`}>{f.prix(g.marge)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </div>
  );
}