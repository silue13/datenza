"use client";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { BlocRapport } from "../../lib/analyse/rapport";
import type { analyserColonnes } from "../../lib/analyse/analyse";
import type { Cellule } from "../../lib/analyse/utils";
import { analyserNettoyage, appliquerCorrections } from "../../lib/analyse/nettoyage";
import {
  appliquerFiltres,
  ajouterColonneCalculee,
  type ConditionFiltre,
  type DefinitionColonneCalculee,
} from "../../lib/analyse/filtres";
import { chargerEtat, sauvegarderEtat, effacerEtat } from "../../lib/persistance";

export type ResultatAnalyse = ReturnType<typeof analyserColonnes>;
export type TypeGraphique = "Barres" | "Courbe" | "Camembert" | "Anneau" | "Radar" | "Aires" | "Carte";

export interface GraphiqueEpingle {
  id: number;
  titre: string;
  type: TypeGraphique;
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor: string | string[];
    borderColor?: string;
    borderWidth?: number;
    borderRadius?: number;
  }[];
}

interface DataContextType {
  nomFichier: string;
  entetes: string[];
  corps: Cellule[][];
  choisies: string[];
  rapport: BlocRapport[];
  resultat: ResultatAnalyse | null;
  graphiquesEpingles: GraphiqueEpingle[];
  filtresActifs: ConditionFiltre[];
  chargerDonnees: (
    nom: string,
    entetes: string[],
    corps: Cellule[][],
    nouveauResultat?: ResultatAnalyse | null,
    nouveauRapport?: BlocRapport[]
  ) => void;
  setChoisies: React.Dispatch<React.SetStateAction<string[]>>;
  setRapport: React.Dispatch<React.SetStateAction<BlocRapport[]>>;
  setResultat: React.Dispatch<React.SetStateAction<ResultatAnalyse | null>>;
  epinglerGraphique: (graphique: GraphiqueEpingle) => void;
  desepinglerGraphique: (id: number) => void;
  ajouterFiltre: (filtre: ConditionFiltre) => void;
  supprimerFiltre: (index: number) => void;
  reinitialiserFiltres: () => void;
  creerColonneCalculee: (def: DefinitionColonneCalculee) => void;
  nettoyerDonnees: (corrections: { colonne: string; valeurOriginale: any; valeurSuggeree: any }[]) => void;
  supprimerDonnees: () => void;
  // false tant que la sauvegarde locale n'a pas été relue (évite d'afficher « aucun fichier » une fraction de seconde)
  restaurationTerminee: boolean;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [nomFichier, setNomFichier] = useState<string>("");
  const [sources, setSources] = useState<{ entetes: string[]; corps: Cellule[][] }>({ entetes: [], corps: [] });
  const [entetes, setEntetes] = useState<string[]>([]);
  const [corps, setCorps] = useState<Cellule[][]>([]);
  const [choisies, setChoisies] = useState<string[]>([]);
  const [rapport, setRapport] = useState<BlocRapport[]>([]);
  const [resultat, setResultat] = useState<ResultatAnalyse | null>(null);
  const [graphiquesEpingles, setGraphiquesEpingles] = useState<GraphiqueEpingle[]>([]);
  const [filtresActifs, setFiltresActifs] = useState<ConditionFiltre[]>([]);
  const [definitionsCalculs, setDefinitionsCalculs] = useState<DefinitionColonneCalculee[]>([]);
  const [restaurationTerminee, setRestaurationTerminee] = useState(false);

  // Recalcule le jeu de données affiché à partir des sources, calculs et filtres
  function regenererDonnees(
    baseEntetes: string[],
    baseCorps: Cellule[][],
    calculs: DefinitionColonneCalculee[],
    filtres: ConditionFiltre[]
  ) {
    if (!baseEntetes.length || !baseCorps.length) return;

    // 1. Conversion en objets
    let objs = baseCorps.map((ligne) => {
      const obj: Record<string, any> = {};
      baseEntetes.forEach((h, idx) => {
        obj[h] = ligne[idx];
      });
      return obj;
    });

    // 2. Application des colonnes calculées
    for (const def of calculs) {
      objs = ajouterColonneCalculee(objs, def);
    }

    // 3. Application des filtres
    const objsFiltres = appliquerFiltres(objs, filtres);

    // 4. Reconstruction des entêtes et corps finaux
    const entetesFinales = [...baseEntetes, ...calculs.map((c) => c.nomNouvelleColonne)];
    const corpsFinal: Cellule[][] = objsFiltres.map((obj) => entetesFinales.map((h) => obj[h]));

    setEntetes(entetesFinales);
    setCorps(corpsFinal);
    setChoisies((prev) => Array.from(new Set([...prev, ...calculs.map((c) => c.nomNouvelleColonne)])));
  }

  function chargerDonnees(
    nom: string,
    entetesData: string[],
    corpsData: Cellule[][],
    nouveauResultat?: ResultatAnalyse | null,
    nouveauRapport?: BlocRapport[]
  ) {
    // Nettoyage automatique initial de la casse
    const donneesObjets = corpsData.map((ligne) => {
      const obj: Record<string, any> = {};
      entetesData.forEach((h, idx) => {
        obj[h] = ligne[idx];
      });
      return obj;
    });

    const rapportNettoyage = analyserNettoyage(donneesObjets);
    const corrections: { colonne: string; valeurOriginale: any; valeurSuggeree: any }[] = [];
    Object.values(rapportNettoyage.suggestionsParColonne).forEach((suggestions) => {
      suggestions.forEach((s) => {
        if (s.colonne && s.valeurOriginale && s.valeurSuggeree) {
          corrections.push({
            colonne: s.colonne,
            valeurOriginale: s.valeurOriginale,
            valeurSuggeree: s.valeurSuggeree,
          });
        }
      });
    });

    let corpsNettoye = corpsData;
    if (corrections.length > 0) {
      const donneesPropres = appliquerCorrections(donneesObjets, corrections);
      corpsNettoye = donneesPropres.map((obj) => entetesData.map((h) => obj[h]));
    }

    setNomFichier(nom);
    setSources({ entetes: entetesData, corps: corpsNettoye });
    setEntetes(entetesData);
    setCorps(corpsNettoye);
    setChoisies(entetesData);
    setFiltresActifs([]);
    setDefinitionsCalculs([]);

    // Conserve le résultat et le rapport fournis lors d'une fusion
    setRapport(nouveauRapport ?? []);
    setResultat(nouveauResultat ?? null);
    setGraphiquesEpingles([]);
  }

  function ajouterFiltre(filtre: ConditionFiltre) {
    const maj = [...filtresActifs, filtre];
    setFiltresActifs(maj);
    regenererDonnees(sources.entetes, sources.corps, definitionsCalculs, maj);
  }

  function supprimerFiltre(index: number) {
    const maj = filtresActifs.filter((_, i) => i !== index);
    setFiltresActifs(maj);
    regenererDonnees(sources.entetes, sources.corps, definitionsCalculs, maj);
  }

  function reinitialiserFiltres() {
    setFiltresActifs([]);
    regenererDonnees(sources.entetes, sources.corps, definitionsCalculs, []);
  }

  function creerColonneCalculee(def: DefinitionColonneCalculee) {
    const maj = [...definitionsCalculs, def];
    setDefinitionsCalculs(maj);
    regenererDonnees(sources.entetes, sources.corps, maj, filtresActifs);
  }

  // Applique des corrections de variantes (casse, doublons de texte) sur les données sources, puis régénère l'affichage
  function nettoyerDonnees(corrections: { colonne: string; valeurOriginale: any; valeurSuggeree: any }[]) {
    if (!corrections.length) return;
    const objs = sources.corps.map((ligne) => {
      const obj: Record<string, any> = {};
      sources.entetes.forEach((h, idx) => {
        obj[h] = ligne[idx];
      });
      return obj;
    });
    const propres = appliquerCorrections(objs, corrections);
    const corpsPropre: Cellule[][] = propres.map((obj) => sources.entetes.map((h) => obj[h]));
    setSources({ entetes: sources.entetes, corps: corpsPropre });
    regenererDonnees(sources.entetes, corpsPropre, definitionsCalculs, filtresActifs);
  }

  // Au premier affichage : relit la sauvegarde locale (les données survivent au rechargement de la page)
  useEffect(() => {
    let annule = false;
    chargerEtat().then((etat) => {
      if (annule) return;
      if (etat) {
        setNomFichier(etat.nomFichier);
        setSources(etat.sources);
        setDefinitionsCalculs(etat.definitionsCalculs);
        setFiltresActifs(etat.filtresActifs);
        regenererDonnees(etat.sources.entetes, etat.sources.corps, etat.definitionsCalculs, etat.filtresActifs);
        setChoisies(etat.choisies);
        setRapport(etat.rapport);
        setResultat(etat.resultat);
        setGraphiquesEpingles(etat.graphiquesEpingles);
      }
      setRestaurationTerminee(true);
    });
    return () => {
      annule = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sauvegarde automatique à chaque modification (après la restauration, jamais avant)
  useEffect(() => {
    if (!restaurationTerminee) return;
    if (!sources.corps.length) {
      void effacerEtat();
      return;
    }
    const minuteur = setTimeout(() => {
      void sauvegarderEtat({
        nomFichier,
        sources,
        choisies,
        rapport,
        resultat,
        graphiquesEpingles,
        filtresActifs,
        definitionsCalculs,
      });
    }, 600);
    return () => clearTimeout(minuteur);
  }, [restaurationTerminee, nomFichier, sources, choisies, rapport, resultat, graphiquesEpingles, filtresActifs, definitionsCalculs]);

  // Suppression volontaire : efface les données à l'écran ET la sauvegarde locale
  function supprimerDonnees() {
    setNomFichier("");
    setSources({ entetes: [], corps: [] });
    setEntetes([]);
    setCorps([]);
    setChoisies([]);
    setRapport([]);
    setResultat(null);
    setGraphiquesEpingles([]);
    setFiltresActifs([]);
    setDefinitionsCalculs([]);
    void effacerEtat();
  }

  function epinglerGraphique(graphique: GraphiqueEpingle) {
    setGraphiquesEpingles((prev) => (prev.some((g) => g.id === graphique.id) ? prev : [graphique, ...prev]));
  }

  function desepinglerGraphique(id: number) {
    setGraphiquesEpingles((prev) => prev.filter((g) => g.id !== id));
  }

  return (
    <DataContext.Provider
      value={{
        nomFichier,
        entetes,
        corps,
        choisies,
        rapport,
        resultat,
        graphiquesEpingles,
        filtresActifs,
        chargerDonnees,
        setChoisies,
        setRapport,
        setResultat,
        epinglerGraphique,
        desepinglerGraphique,
        ajouterFiltre,
        supprimerFiltre,
        reinitialiserFiltres,
        creerColonneCalculee,
        nettoyerDonnees,
        supprimerDonnees,
        restaurationTerminee,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData doit être utilisé dans un DataProvider");
  }
  return context;
}