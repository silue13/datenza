import { arrondir } from "./utils";
import { interpreterCorrelation } from "./stats";
import { estPseudoMesure } from "./mesures";
import { creerFormateurs, natureValeur } from "./format";
import type { analyserColonnes } from "./analyse";

type Resultat = ReturnType<typeof analyserColonnes>;
export type Langue = "fr" | "en";
export interface BlocRapport {
  type: "intro" | "qualite" | "mesure" | "categorie" | "numerique" | "booleen" | "date" | "correlation";
  texte: string;
}

type Cat = { total: number; nbCategoriesDistinctes: number; topValeurs: { valeur: string; effectif: number; pourcentage: number }[] };
type Num = { n: number; moyenne: number; mediane: number; min: number; max: number; atypiques: number };
type Dat = { n: number; min: string; max: string };
type Boo = { vrai: number; faux: number };

export function genererRapport(res: Resultat, langue: Langue = "fr"): BlocRapport[] {
  const L = (fr: string, en: string) => (langue === "en" ? en : fr);
  const blocs: BlocRapport[] = [];
  const st = res.statistiques;
  const noms = Object.keys(st);
  const de = (type: string) => noms.filter((n) => st[n].type === type);
  const F = creerFormateurs(langue);
  const cellules = res.nbLignes * noms.length;
  const manquants = noms.reduce((s, n) => s + st[n].nbVides, 0);

  blocs.push({ type: "intro", texte: L(`${F.nombre(res.nbLignes)} lignes analysées sur ${noms.length} champ(s).`, `${F.nombre(res.nbLignes)} rows analyzed across ${noms.length} field(s).`) });
  blocs.push({
    type: "qualite",
    texte: manquants
      ? L(`${F.nombre(manquants)} valeur(s) manquante(s) sur ${F.nombre(cellules)} cellules (${F.pourcent(arrondir((100 * manquants) / cellules))}).`, `${F.nombre(manquants)} missing value(s) out of ${F.nombre(cellules)} cells (${F.pourcent(arrondir((100 * manquants) / cellules))}).`)
      : L(`Aucune valeur manquante sur ${F.nombre(cellules)} cellules.`, `No missing values across ${F.nombre(cellules)} cells.`),
  });

  const score = (n: string) => {
    const d = (st[n].stats as Cat).nbCategoriesDistinctes;
    return (st[n].role === "statut" ? 100 : 40) + (d >= 2 && d <= 15 ? 30 : 0) - (d > 50 ? 40 : 0);
  };
  // Répartition des mesures numériques par catégorie : c'est la lecture utile, plus que les simples effectifs.
  const couvertes = new Set<string>();
  for (const mesure of res.mesures) {
    const op = mesure.operation === "somme" ? L("total", "total") : L("moyenne", "average");
    const nf = F.pour(natureValeur(mesure.colonne));
    if (mesure.totalGlobal !== null) {
      blocs.push({ type: "mesure", texte: L(`${mesure.colonne} : ${nf(mesure.totalGlobal)} au total.`, `${mesure.colonne}: ${nf(mesure.totalGlobal)} in total.`) });
    }
    for (const r of mesure.repartitions) {
      if (!r.lignes.length) continue;
      couvertes.add(r.dimension);
      const liste = r.lignes.map((x) => `${x.valeur} (${nf(x.total)}${x.part !== null ? `, ${F.pourcent(x.part)}` : ""})`).join(", ");
      blocs.push({
        type: "mesure",
        texte: L(`${mesure.colonne} (${op}) par ${r.dimension} : ${liste}.`, `${mesure.colonne} (${op}) by ${r.dimension}: ${liste}.`),
      });
    }
  }
  const mp = res.mesures.length > 0;

  // Sans mesure exploitable, on retombe sur les fréquences ; les statuts gardent toujours leurs effectifs.
  de("categorielle").filter((n) => !couvertes.has(n) || st[n].role === "statut").sort((a, b) => score(b) - score(a)).slice(0, mp ? 3 : 6).forEach((n) => {
    const s = st[n].stats as Cat;
    const top = s.topValeurs[0];
    if (!top) return;
    let t = L(
      `${n} : « ${top.valeur} » est la modalité la plus fréquente (${top.effectif} lignes, ${top.pourcentage} %) sur ${s.total} valeurs renseignées.`,
      `${n}: “${top.valeur}” is the most frequent value (${top.effectif} rows, ${top.pourcentage} %) out of ${s.total} reported values.`
    );
    if (st[n].role === "statut" && s.topValeurs.length > 1)
      t += L(" Principaux statuts : ", " Main statuses: ") + s.topValeurs.map((v) => `${v.valeur} (${v.pourcentage} %)`).join(", ") + ".";
    blocs.push({ type: "categorie", texte: t });
  });

  de("numerique").filter((n) => !estPseudoMesure(n)).slice(0, 8).forEach((n) => {
    const s = st[n].stats as Num;
    if (!s.n) return;
    let t = L(
      `${n} : moyenne ${F.nombre(s.moyenne)}, médiane ${F.nombre(s.mediane)}, minimum ${F.nombre(s.min)}, maximum ${F.nombre(s.max)}.`,
      `${n}: average ${F.nombre(s.moyenne)}, median ${F.nombre(s.mediane)}, minimum ${F.nombre(s.min)}, maximum ${F.nombre(s.max)}.`
    );
    if (s.atypiques) t += L(` ${s.atypiques} valeur(s) atypique(s) à examiner.`, ` ${s.atypiques} potential outlier(s) to review.`);
    blocs.push({ type: "numerique", texte: t });
  });

  de("booleen").forEach((n) => {
    const s = st[n].stats as Boo;
    blocs.push({ type: "booleen", texte: L(`${n} : ${s.vrai} oui, ${s.faux} non.`, `${n}: ${s.vrai} yes, ${s.faux} no.`) });
  });

  de("date").forEach((n) => {
    const s = st[n].stats as Dat;
    if (!s.n) return;
    blocs.push({ type: "date", texte: L(`${n} : du ${s.min.slice(0, 10)} au ${s.max.slice(0, 10)}.`, `${n}: from ${s.min.slice(0, 10)} to ${s.max.slice(0, 10)}.`) });
  });

  res.correlations
    .filter((c) => Math.abs(c.coefficient) >= 0.6)
    .sort((a, b) => Math.abs(b.coefficient) - Math.abs(a.coefficient))
    .slice(0, 3)
    .forEach((c) => {
      const force = interpreterCorrelation(c.coefficient, langue);
      blocs.push({
        type: "correlation",
        texte: L(`${c.colonneA} et ${c.colonneB} : relation ${force} (r = ${c.coefficient}).`, `${c.colonneA} and ${c.colonneB}: ${force} relationship (r = ${c.coefficient}).`),
      });
    });

  return blocs;
}