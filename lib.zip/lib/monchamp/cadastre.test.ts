import { describe, expect, it } from "vitest";
import type { Campagne } from "./calculs";
import {
  aireM2,
  basculerEau,
  centre,
  contourSeCroise,
  contourValide,
  historiqueParcelle,
  superficieHa,
  type Coord,
  type ParcelleCadastre,
} from "./cadastre";

// Carré d'environ 100 m x 100 m à Abidjan (≈ 5,35° N).
const LAT = 5.35, LNG = -4.0;
const dLat = 100 / 111_319.49;
const dLng = 100 / (111_319.49 * Math.cos((LAT * Math.PI) / 180));
const carre: Coord[] = [[LAT, LNG], [LAT, LNG + dLng], [LAT + dLat, LNG + dLng], [LAT + dLat, LNG]];

describe("monchamp/cadastre — géométrie", () => {
  it("mesure environ 1 ha pour un carré de 100 m de côté", () => {
    expect(Math.abs(aireM2(carre) - 10_000) / 10_000 < 0.01).toBe(true);
    expect(Math.abs(superficieHa(carre) - 1) < 0.01).toBe(true);
  });
  it("ne dépend pas du sens de parcours", () => {
    expect(Math.abs(aireM2([...carre].reverse()) - aireM2(carre)) < 1e-6).toBe(true);
  });
  it("renvoie 0 sous 3 points", () => {
    expect(aireM2([[5, -4], [5.1, -4.1]])).toBe(0);
  });
  it("détecte un contour qui se croise (nœud papillon) et pas un carré", () => {
    const noeud: Coord[] = [[0, 0], [1, 1], [1, 0], [0, 1]];
    expect(contourSeCroise(noeud)).toBe(true);
    expect(contourSeCroise(carre)).toBe(false);
  });
  it("calcule le centre", () => {
    expect(centre([[0, 0], [2, 4]])).toEqual([1, 2]);
    expect(centre([])).toBeNull();
  });
  it("valide les contours (localStorage peut contenir n'importe quoi)", () => {
    expect(contourValide(carre)).toBe(true);
    expect(contourValide([[1, 2], [3, 4]])).toBe(false);
    expect(contourValide([[1, 2], [3, 4], ["a", 5]])).toBe(false);
    expect(contourValide([[95, 2], [3, 4], [5, 6]])).toBe(false);
    expect(contourValide(undefined)).toBe(false);
  });
});

describe("monchamp/cadastre — accès à l'eau", () => {
  it("« pluie » est exclusif", () => {
    expect(basculerEau(["puits", "forage"], "pluie")).toEqual(["pluie"]);
    expect(basculerEau(["pluie"], "puits")).toEqual(["puits"]);
    expect(basculerEau(["puits"], "forage")).toEqual(["puits", "forage"]);
    expect(basculerEau(["puits"], "puits")).toEqual([]);
  });
});

describe("monchamp/cadastre — historique", () => {
  it("fusionne campagnes et antécédents, du plus récent au plus ancien", () => {
    const p: ParcelleCadastre = {
      id: 1, nom: "Bas-fond", localite: "", superficieHa: 2,
      antecedents: [{ id: 1, annee: 2024, culture: "Igname", note: "jachère après" }, { id: 2, annee: 2026, culture: "Riz" }],
    };
    const camp = (id: number, parcelleId: number, annee: number, statut?: Campagne["statut"]): Campagne => ({
      id, parcelleId, culture: "Maïs", annee, quantiteKg: 1200, prixKg: 200, charges: 0, statut,
    });
    const h = historiqueParcelle(p, [camp(1, 1, 2026, "en_cours"), camp(2, 1, 2025), camp(3, 2, 2025)]);
    expect(h.map((x) => x.cle)).toEqual(["c1", "a2", "c2", "a1"]);
    expect(h[0].enCours).toBe(true);
    expect(h[0].quantiteKg).toBe(undefined);
    expect(h[2].quantiteKg).toBe(1200);
  });
});