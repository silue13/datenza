// lib/monchamp/cadastre.ts
// Cadastre de l'exploitation : contour GPS, superficie mesurée, sol, accès à l'eau, historique.
// Fonctions pures (sans React ni Leaflet), testables.
import type { Campagne, Parcelle } from "./calculs";

/** Coordonnées [latitude, longitude], dans l'ordre attendu par Leaflet. */
export type Coord = [number, number];

export type TypeSol = "sableux" | "argileux" | "limoneux" | "argilo_sableux" | "gravillonnaire" | "hydromorphe" | "autre";
export type AccesEau = "pluie" | "cours_eau" | "puits" | "forage" | "irrigation";

export interface Antecedent {
  id: number;
  annee: number;
  culture: string;
  note?: string;
}

/** Parcelle enrichie des informations cadastrales (tous les champs ajoutés sont facultatifs). */
export interface ParcelleCadastre extends Parcelle {
  contour?: Coord[];
  sol?: TypeSol;
  eau?: AccesEau[];
  antecedents?: Antecedent[];
}

export interface EntreeHistorique {
  cle: string;
  annee: number;
  culture: string;
  source: "campagne" | "antecedent";
  enCours?: boolean;
  quantiteKg?: number;
  note?: string;
  antecedentId?: number;
}

export const LIBELLE_SOL: Record<TypeSol, string> = {
  sableux: "Sableux",
  argileux: "Argileux",
  limoneux: "Limoneux",
  argilo_sableux: "Argilo-sableux",
  gravillonnaire: "Gravillonnaire",
  hydromorphe: "Bas-fond hydromorphe",
  autre: "Autre",
};

export const LIBELLE_EAU: Record<AccesEau, string> = {
  pluie: "Pluie uniquement",
  cours_eau: "Rivière / marigot à proximité",
  puits: "Puits",
  forage: "Forage",
  irrigation: "Système d'irrigation",
};

const RAYON_TERRE_M = 6_378_137;
const RAD = Math.PI / 180;

/** Vrai si `c` est un contour exploitable : au moins 3 points [lat, lng] réels et dans les bornes. */
export function contourValide(c: unknown): c is Coord[] {
  return (
    Array.isArray(c) &&
    c.length >= 3 &&
    c.every(
      (p) =>
        Array.isArray(p) &&
        p.length === 2 &&
        Number.isFinite(p[0]) &&
        Number.isFinite(p[1]) &&
        Math.abs(p[0]) <= 90 &&
        Math.abs(p[1]) <= 180
    )
  );
}

/** Aire d'un polygone sur la sphère terrestre, en m² (formule géodésique de Chamberlain & Duquette). */
export function aireM2(contour: Coord[]): number {
  if (contour.length < 3) return 0;
  let somme = 0;
  for (let i = 0; i < contour.length; i++) {
    const [lat1, lng1] = contour[i];
    const [lat2, lng2] = contour[(i + 1) % contour.length];
    somme += (lng2 - lng1) * RAD * (2 + Math.sin(lat1 * RAD) + Math.sin(lat2 * RAD));
  }
  return Math.abs((somme * RAYON_TERRE_M * RAYON_TERRE_M) / 2);
}

/** Superficie en hectares (1 ha = 10 000 m²). */
export function superficieHa(contour: Coord[]): number {
  return aireM2(contour) / 10_000;
}

/** Centre approximatif du contour (moyenne des sommets) ; null si le contour est vide. */
export function centre(contour: Coord[]): Coord | null {
  if (!contour.length) return null;
  const lat = contour.reduce((s, p) => s + p[0], 0) / contour.length;
  const lng = contour.reduce((s, p) => s + p[1], 0) / contour.length;
  return [lat, lng];
}

const orient = (a: Coord, b: Coord, c: Coord) => (b[1] - a[1]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[1] - a[1]);

function segmentsSecoupent(a: Coord, b: Coord, c: Coord, d: Coord): boolean {
  const o1 = orient(a, b, c), o2 = orient(a, b, d), o3 = orient(c, d, a), o4 = orient(c, d, b);
  return o1 * o2 < 0 && o3 * o4 < 0; // croisement strict (les contacts aux sommets ne comptent pas)
}

/** Vrai si deux côtés non voisins se croisent : la superficie d'un tel contour n'est pas fiable. */
export function contourSeCroise(contour: Coord[]): boolean {
  const n = contour.length;
  if (n < 4) return false;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      if (j === i + 1 || (i === 0 && j === n - 1)) continue; // côtés voisins
      if (segmentsSecoupent(contour[i], contour[(i + 1) % n], contour[j], contour[(j + 1) % n])) return true;
    }
  }
  return false;
}

export function formaterCoord(c: Coord): string {
  return `${c[0].toFixed(5)}, ${c[1].toFixed(5)}`;
}

/**
 * Coche / décoche un accès à l'eau. « Pluie uniquement » est exclusif :
 * le cocher retire les autres sources, cocher une autre source retire « pluie ».
 */
export function basculerEau(actuel: AccesEau[], valeur: AccesEau): AccesEau[] {
  if (actuel.includes(valeur)) return actuel.filter((x) => x !== valeur);
  if (valeur === "pluie") return ["pluie"];
  return [...actuel.filter((x) => x !== "pluie"), valeur];
}

/** Historique d'exploitation : campagnes enregistrées + antécédents saisis à la main, du plus récent au plus ancien. */
export function historiqueParcelle(p: ParcelleCadastre, campagnes: Campagne[]): EntreeHistorique[] {
  const deCampagnes: EntreeHistorique[] = campagnes
    .filter((c) => c.parcelleId === p.id)
    .map((c) => ({
      cle: `c${c.id}`,
      annee: c.annee,
      culture: c.culture,
      source: "campagne" as const,
      enCours: c.statut === "en_cours",
      quantiteKg: c.statut === "en_cours" ? undefined : c.quantiteKg,
    }));
  const deAntecedents: EntreeHistorique[] = (p.antecedents ?? []).map((a) => ({
    cle: `a${a.id}`,
    annee: a.annee,
    culture: a.culture,
    source: "antecedent" as const,
    note: a.note,
    antecedentId: a.id,
  }));
  return [...deCampagnes, ...deAntecedents].sort(
    (x, y) => y.annee - x.annee || Number(y.source === "campagne") - Number(x.source === "campagne")
  );
}