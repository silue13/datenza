// lib/monchamp/calculs.ts
// Moteur MonChamp : calculs agricoles purs (sans React, sans stockage), testables.

export type EtatParcelle = "bon" | "surveiller" | "probleme";
export type StatutCampagne = "en_cours" | "recoltee";

export interface Parcelle {
  id: number;
  nom: string;
  localite: string;
  superficieHa: number;
  etat?: EtatParcelle; // état déclaré par l'exploitant ; absent = non évalué
}

export interface Campagne {
  id: number;
  parcelleId: number;
  culture: string;
  annee: number;
  quantiteKg: number; // production récoltée (0 tant que la campagne est en cours)
  prixKg: number; // prix de vente (FCFA / kg)
  charges: number; // total des dépenses de la campagne (FCFA)
  statut?: StatutCampagne; // absent = récoltée (anciennes données)
  dateRecoltePrevue?: string; // AAAA-MM-JJ, pour les campagnes en cours
}

export interface BilanCulture {
  culture: string;
  nbCampagnes: number;
  superficieHa: number;
  quantiteKg: number;
  recette: number;
  charges: number;
  marge: number;
  rendementKgHa: number | null;
}

const cle = (s: string) => s.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

/** Une campagne sans statut est considérée récoltée (compatibilité avec les premières données). */
export const estRecoltee = (c: Campagne) => c.statut !== "en_cours";

export const recette = (c: Campagne) => c.quantiteKg * c.prixKg;
export const marge = (c: Campagne) => recette(c) - c.charges;

/** Marge en % de la recette ; null si aucune recette (division par zéro). */
export function margePourcent(c: Campagne): number | null {
  const r = recette(c);
  return r > 0 ? (marge(c) / r) * 100 : null;
}

/** Rendement en kg/ha ; null si la superficie est inconnue ou nulle. */
export function rendementKgHa(c: Campagne, p: Parcelle | undefined): number | null {
  return p && p.superficieHa > 0 ? c.quantiteKg / p.superficieHa : null;
}

/**
 * Regroupe par culture les campagnes RÉCOLTÉES (« Maïs » et « mais » sont la même culture).
 * Les campagnes en cours sont exclues : sans récolte, leurs charges fausseraient la marge.
 */
export function bilanParCulture(campagnes: Campagne[], parcelles: Parcelle[]): BilanCulture[] {
  const groupes = new Map<string, BilanCulture>();
  for (const c of campagnes.filter(estRecoltee)) {
    const k = cle(c.culture);
    const p = parcelles.find((x) => x.id === c.parcelleId);
    const g =
      groupes.get(k) ??
      { culture: c.culture.trim(), nbCampagnes: 0, superficieHa: 0, quantiteKg: 0, recette: 0, charges: 0, marge: 0, rendementKgHa: null };
    g.nbCampagnes += 1;
    g.superficieHa += p?.superficieHa ?? 0;
    g.quantiteKg += c.quantiteKg;
    g.recette += recette(c);
    g.charges += c.charges;
    g.marge += marge(c);
    groupes.set(k, g);
  }
  return [...groupes.values()]
    .map((g) => ({ ...g, rendementKgHa: g.superficieHa > 0 ? g.quantiteKg / g.superficieHa : null }))
    .sort((a, b) => b.marge - a.marge);
}

/** Bilan des campagnes récoltées uniquement. */
export function bilanGlobal(campagnes: Campagne[]) {
  const finies = campagnes.filter(estRecoltee);
  const recettes = finies.reduce((s, c) => s + recette(c), 0);
  const charges = finies.reduce((s, c) => s + c.charges, 0);
  return { recettes, charges, marge: recettes - charges, margePct: recettes > 0 ? ((recettes - charges) / recettes) * 100 : null };
}