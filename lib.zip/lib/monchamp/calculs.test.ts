import { describe, expect, it } from "vitest";
import { bilanGlobal, bilanParCulture, margePourcent, rendementKgHa, type Campagne, type Parcelle } from "./calculs";

const parcelles: Parcelle[] = [
  { id: 1, nom: "Bas-fond", localite: "Korhogo", superficieHa: 2 },
  { id: 2, nom: "Plateau", localite: "Korhogo", superficieHa: 0 },
];
const base: Campagne = { id: 1, parcelleId: 1, culture: "Maïs", annee: 2026, quantiteKg: 4000, prixKg: 200, charges: 300000 };

describe("monchamp/calculs", () => {
  it("calcule marge et rendement", () => {
    expect(margePourcent(base)).toBeCloseTo(62.5);
    expect(rendementKgHa(base, parcelles[0])).toBe(2000);
  });
  it("renvoie null sans recette ni superficie", () => {
    expect(margePourcent({ ...base, quantiteKg: 0 })).toBeNull();
    expect(rendementKgHa(base, parcelles[1])).toBeNull();
    expect(rendementKgHa(base, undefined)).toBeNull();
  });
  it("regroupe « Maïs » et « mais » dans la même culture", () => {
    const b = bilanParCulture([base, { ...base, id: 2, culture: " mais " }], parcelles);
    expect(b).toHaveLength(1);
    expect(b[0].nbCampagnes).toBe(2);
    expect(b[0].marge).toBe(1000000);
  });
  it("exclut les campagnes en cours des bilans", () => {
    const enCours: Campagne = { ...base, id: 3, statut: "en_cours", quantiteKg: 0, charges: 150000 };
    expect(bilanGlobal([base, enCours]).charges).toBe(300000);
    expect(bilanParCulture([base, enCours], parcelles)[0].nbCampagnes).toBe(1);
  });
  it("bilan global", () => {
    expect(bilanGlobal([base]).marge).toBe(500000);
    expect(bilanGlobal([]).margePct).toBeNull();
  });
});