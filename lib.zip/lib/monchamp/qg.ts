// lib/monchamp/qg.ts
// « QG de l'Exploitant » : synthèse de la santé des terres, des travaux prioritaires et des récoltes à venir.
// Fonctions pures : la date du jour est toujours passée en paramètre (AAAA-MM-JJ) pour rester testable.
import type { Campagne, EtatParcelle, Parcelle } from "./calculs";

export type Priorite = "haute" | "normale" | "basse";
export type NiveauSante = EtatParcelle | "non_evalue";

export interface Travail {
  id: number;
  parcelleId: number | null; // null = toute l'exploitation
  libelle: string;
  echeance: string; // AAAA-MM-JJ
  priorite: Priorite;
  fait: boolean;
}

export interface TravailUrgent extends Travail {
  joursRestants: number;
  enRetard: boolean;
}

export interface RecolteAVenir {
  campagne: Campagne;
  joursRestants: number;
  enRetard: boolean; // date prévue dépassée mais campagne pas encore marquée récoltée
  proche: boolean; // dans les 14 jours
}

export interface SanteParcelle {
  parcelle: Parcelle;
  niveau: NiveauSante;
  raisons: string[];
}

const RE_JOUR = /^(\d{4})-(\d{2})-(\d{2})$/;

export function jourValide(s: string): boolean {
  const m = RE_JOUR.exec(s);
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}

/** Date locale du jour au format AAAA-MM-JJ (le jour vu par l'exploitant, pas l'UTC). */
export function jourISO(d: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** Nombre de jours de `de` à `a` (négatif si `a` est avant `de`). Les deux dates doivent être valides. */
export function ecartJours(de: string, a: string): number {
  const t = (s: string) => {
    const m = RE_JOUR.exec(s);
    return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) : NaN;
  };
  return Math.round((t(a) - t(de)) / 86_400_000);
}

export function formaterJour(iso: string): string {
  const m = RE_JOUR.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}

export function libelleJours(j: number): string {
  if (j === 0) return "aujourd'hui";
  if (j === 1) return "demain";
  if (j > 1) return `dans ${j} jours`;
  if (j === -1) return "en retard d'1 jour";
  return `en retard de ${-j} jours`;
}

const POIDS: Record<Priorite, number> = { haute: 0, normale: 1, basse: 2 };

/** Travaux non faits : d'abord les retards, puis la priorité, puis l'échéance la plus proche. */
export function travauxPrioritaires(travaux: Travail[], aujourdhui: string, limite = 5): TravailUrgent[] {
  return travaux
    .filter((t) => !t.fait && jourValide(t.echeance))
    .map((t) => {
      const j = ecartJours(aujourdhui, t.echeance);
      return { ...t, joursRestants: j, enRetard: j < 0 };
    })
    .sort(
      (a, b) =>
        Number(b.enRetard) - Number(a.enRetard) ||
        POIDS[a.priorite] - POIDS[b.priorite] ||
        a.joursRestants - b.joursRestants
    )
    .slice(0, limite);
}

/** Campagnes en cours avec une date de récolte prévue, de la plus proche (ou la plus en retard) à la plus lointaine. */
export function recoltesAVenir(campagnes: Campagne[], aujourdhui: string): RecolteAVenir[] {
  return campagnes
    .filter((c) => c.statut === "en_cours" && !!c.dateRecoltePrevue && jourValide(c.dateRecoltePrevue))
    .map((c) => {
      const j = ecartJours(aujourdhui, c.dateRecoltePrevue as string);
      return { campagne: c, joursRestants: j, enRetard: j < 0, proche: j >= 0 && j <= 14 };
    })
    .sort((a, b) => a.joursRestants - b.joursRestants);
}

const RANG: Record<NiveauSante, number> = { non_evalue: 0, bon: 1, surveiller: 2, probleme: 3 };
const pire = (a: NiveauSante, b: NiveauSante): NiveauSante => (RANG[b] > RANG[a] ? b : a);
const LIBELLE_ETAT: Record<EtatParcelle, string> = { bon: "bon", surveiller: "à surveiller", probleme: "problème" };

/**
 * Santé des terres. Rien n'est mesuré (pas de capteur) : le niveau part de l'état que l'exploitant a déclaré,
 * puis se dégrade si des travaux sont en retard sur la parcelle (1 retard → à surveiller, 3 ou plus → problème).
 * Sans état déclaré ni alerte, la parcelle reste « non évaluée » plutôt que d'être présentée comme saine.
 */
export function santeTerres(parcelles: Parcelle[], travaux: Travail[], campagnes: Campagne[], aujourdhui: string): SanteParcelle[] {
  return parcelles.map((p) => {
    let niveau: NiveauSante = p.etat ?? "non_evalue";
    const raisons: string[] = [];
    if (p.etat && p.etat !== "bon") raisons.push(`État déclaré : ${LIBELLE_ETAT[p.etat]}`);

    const retards = travaux.filter(
      (t) => t.parcelleId === p.id && !t.fait && jourValide(t.echeance) && ecartJours(aujourdhui, t.echeance) < 0
    ).length;
    if (retards > 0) {
      raisons.push(retards === 1 ? "1 travail en retard" : `${retards} travaux en retard`);
      niveau = pire(niveau, retards >= 3 ? "probleme" : "surveiller");
    }

    if (!campagnes.some((c) => c.parcelleId === p.id && c.statut === "en_cours")) raisons.push("Aucune culture en cours");
    return { parcelle: p, niveau, raisons };
  });
}

export function syntheseQG(parcelles: Parcelle[], campagnes: Campagne[], travaux: Travail[], aujourdhui: string) {
  const parNiveau: Record<NiveauSante, number> = { bon: 0, surveiller: 0, probleme: 0, non_evalue: 0 };
  for (const s of santeTerres(parcelles, travaux, campagnes, aujourdhui)) parNiveau[s.niveau]++;
  const ouverts = travaux.filter((t) => !t.fait);
  return {
    nbParcelles: parcelles.length,
    superficieTotaleHa: parcelles.reduce((s, p) => s + p.superficieHa, 0),
    nbCulturesEnCours: campagnes.filter((c) => c.statut === "en_cours").length,
    travauxOuverts: ouverts.length,
    travauxEnRetard: ouverts.filter((t) => jourValide(t.echeance) && ecartJours(aujourdhui, t.echeance) < 0).length,
    parNiveau,
    prochaineRecolte: recoltesAVenir(campagnes, aujourdhui)[0] ?? null,
  };
}