// lib/monchamp/stockage.ts
// Stockage local (navigateur) en attendant Supabase. Même approche que lib/prefs.ts.
import type { Campagne, Parcelle } from "./calculs";
import type { Travail } from "./qg";

const CLE = "datenza-monchamp";

export interface DonneesMonChamp {
  parcelles: Parcelle[];
  campagnes: Campagne[];
  travaux: Travail[];
}

const vide = (): DonneesMonChamp => ({ parcelles: [], campagnes: [], travaux: [] });

export function lireDonnees(): DonneesMonChamp {
  try {
    const brut = window.localStorage.getItem(CLE);
    if (!brut) return vide();
    const o = JSON.parse(brut) as Partial<DonneesMonChamp>;
    return {
      parcelles: Array.isArray(o.parcelles) ? o.parcelles : [],
      campagnes: Array.isArray(o.campagnes) ? o.campagnes : [],
      travaux: Array.isArray(o.travaux) ? o.travaux : [], // absent dans la première version : on démarre à vide
    };
  } catch {
    return vide();
  }
}

export function enregistrerDonnees(d: DonneesMonChamp) {
  try {
    window.localStorage.setItem(CLE, JSON.stringify(d));
  } catch {
    /* stockage indisponible : on ignore */
  }
}