import { describe, expect, it } from "vitest";
import type { Campagne, Parcelle } from "./calculs";
import { ecartJours, jourValide, libelleJours, recoltesAVenir, santeTerres, syntheseQG, travauxPrioritaires, type Travail } from "./qg";

const AUJ = "2026-10-23";
const parcelles: Parcelle[] = [
  { id: 1, nom: "Bas-fond", localite: "Korhogo", superficieHa: 2, etat: "bon" },
  { id: 2, nom: "Plateau", localite: "Korhogo", superficieHa: 1 },
];
const t = (id: number, echeance: string, priorite: Travail["priorite"], parcelleId: number | null = 1, fait = false): Travail => ({
  id, parcelleId, libelle: `t${id}`, echeance, priorite, fait,
});
const camp = (id: number, date: string | undefined, statut: Campagne["statut"] = "en_cours"): Campagne => ({
  id, parcelleId: 1, culture: "Maïs", annee: 2026, quantiteKg: 0, prixKg: 0, charges: 0, statut, dateRecoltePrevue: date,
});

describe("monchamp/qg — dates", () => {
  it("valide et compte les jours", () => {
    expect(jourValide("2026-02-29")).toBe(false);
    expect(jourValide("2028-02-29")).toBe(true);
    expect(jourValide("23/10/2026")).toBe(false);
    expect(ecartJours("2026-10-23", "2026-11-02")).toBe(10);
    expect(ecartJours("2026-10-23", "2026-10-20")).toBe(-3);
    expect(ecartJours("2026-10-25", "2026-10-26")).toBe(1); // changement d'heure : toujours 1 jour
  });
  it("libellés", () => {
    expect(libelleJours(0)).toBe("aujourd'hui");
    expect(libelleJours(3)).toBe("dans 3 jours");
    expect(libelleJours(-1)).toBe("en retard d'1 jour");
    expect(libelleJours(-4)).toBe("en retard de 4 jours");
  });
});

describe("monchamp/qg — travaux", () => {
  it("met les retards d'abord, puis priorité, puis échéance, et ignore les travaux faits", () => {
    const r = travauxPrioritaires(
      [t(1, "2026-10-30", "haute"), t(2, "2026-10-20", "basse"), t(3, "2026-10-25", "haute"), t(4, "2026-10-10", "haute", 1, true), t(5, "2026-10-19", "haute")],
      AUJ
    );
    expect(r.map((x) => x.id)).toEqual([5, 2, 3, 1]);
    expect(r[0].enRetard).toBe(true);
  });
  it("respecte la limite", () => {
    expect(travauxPrioritaires([t(1, "2026-11-01", "haute"), t(2, "2026-11-02", "haute")], AUJ, 1)).toHaveLength(1);
  });
});

describe("monchamp/qg — récoltes", () => {
  it("trie et signale proche / en retard, ignore récoltées et sans date", () => {
    const r = recoltesAVenir([camp(1, "2026-12-01"), camp(2, "2026-10-30"), camp(3, "2026-10-20"), camp(4, undefined), camp(5, "2026-10-25", "recoltee")], AUJ);
    expect(r.map((x) => x.campagne.id)).toEqual([3, 2, 1]);
    expect(r[0].enRetard).toBe(true);
    expect(r[1].proche).toBe(true);
    expect(r[2].proche).toBe(false);
  });
});

describe("monchamp/qg — santé des terres", () => {
  it("n'affirme pas qu'une parcelle est saine sans information", () => {
    const s = santeTerres(parcelles, [], [], AUJ);
    expect(s[0].niveau).toBe("bon");
    expect(s[1].niveau).toBe("non_evalue");
  });
  it("dégrade selon les retards", () => {
    const un = santeTerres(parcelles, [t(1, "2026-10-01", "haute", 2)], [], AUJ);
    expect(un[1].niveau).toBe("surveiller");
    const trois = santeTerres(parcelles, [t(1, "2026-10-01", "haute", 1), t(2, "2026-10-02", "basse", 1), t(3, "2026-10-03", "basse", 1)], [], AUJ);
    expect(trois[0].niveau).toBe("probleme");
  });
  it("ne rétrograde jamais un état déclaré", () => {
    const s = santeTerres([{ ...parcelles[0], etat: "probleme" }], [t(1, "2026-10-01", "haute", 1)], [], AUJ);
    expect(s[0].niveau).toBe("probleme");
  });
});

describe("monchamp/qg — synthèse", () => {
  it("compte parcelles, cultures, travaux", () => {
    const s = syntheseQG(parcelles, [camp(1, "2026-11-05")], [t(1, "2026-10-01", "haute", 1), t(2, "2026-11-01", "basse", 1)], AUJ);
    expect(s.nbParcelles).toBe(2);
    expect(s.superficieTotaleHa).toBe(3);
    expect(s.nbCulturesEnCours).toBe(1);
    expect(s.travauxOuverts).toBe(2);
    expect(s.travauxEnRetard).toBe(1);
    expect(s.prochaineRecolte?.joursRestants).toBe(13);
  });
});